param([switch]$OpenBrowser)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'
$instance = if ($env:EXORTAL_INSTANCE_PATH) { $env:EXORTAL_INSTANCE_PATH } else { Join-Path $backend 'instance' }
$logs = Join-Path $instance 'logs'
$stateFile = Join-Path $instance 'services.json'
New-Item -ItemType Directory -Force $logs | Out-Null
if (Test-Path $stateFile) {
    foreach ($service in (Get-Content $stateFile -Raw | ConvertFrom-Json)) {
        $process = Get-Process -Id $service.pid -ErrorAction SilentlyContinue
        if ($process -and $process.StartTime.ToUniversalTime() -eq ([datetime]$service.started).ToUniversalTime()) {
            throw 'Exortal services are already running. Use Stop-Exortal.ps1 before restarting.'
        }
    }
}
foreach ($port in @(5001, 5180, 6381)) {
    if (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) {
        throw "Port $port is already in use. No existing service will be stopped."
    }
}
$python = Join-Path $root '.venv\Scripts\python.exe'
$tools = Join-Path $env:USERPROFILE '.local\exortal-tools'
$node = Join-Path $tools 'node\node.exe'
if (-not (Test-Path $node)) { $node = (Get-Command node -ErrorAction Stop).Source }
$redis = Join-Path $tools 'redis\Redis-8.10.3-Windows-x64-msys2\redis-server.exe'
if (-not (Test-Path $redis)) { $redis = (Get-Command redis-server -ErrorAction Stop).Source }
if (-not (Test-Path $python)) { throw 'Run Setup-Exortal.ps1 first.' }
$redisData = Join-Path $instance 'redis'
New-Item -ItemType Directory -Force $redisData | Out-Null
$env:PYTHONUNBUFFERED = '1'
$services = [System.Collections.Generic.List[object]]::new()
function Start-TrackedService($name, $program, $arguments, $directory) {
    $process = Start-Process -FilePath $program -ArgumentList $arguments -WorkingDirectory $directory -PassThru -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logs "$name.log") -RedirectStandardError (Join-Path $logs "$name.error.log")
    $services.Add([pscustomobject]@{ name = $name; pid = $process.Id; started = $process.StartTime.ToUniversalTime().ToString('o') })
    $services | ConvertTo-Json | Set-Content $stateFile
}
try {
    Start-TrackedService 'redis' $redis '--bind 127.0.0.1 --port 6381 --protected-mode yes --appendonly yes' $redisData
    Start-TrackedService 'backend' $python 'app.py --port 5001' $backend
    Start-TrackedService 'worker' $python '-m celery -A routes.worker.celery worker --pool=solo --loglevel=info' $backend
    Start-TrackedService 'beat' $python "-m celery -A routes.worker.celery beat --loglevel=info --schedule `"$instance\celerybeat`"" $backend
    Start-TrackedService 'frontend' $node "`"$frontend\node_modules\vite\bin\vite.js`" --host 127.0.0.1 --port 5180 --strictPort" $frontend
    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Seconds 1
        $allAlive = $true
        foreach ($service in $services) {
            if (-not (Get-Process -Id $service.pid -ErrorAction SilentlyContinue)) { $allAlive = $false }
        }
        if (-not $allAlive) { throw "A service exited. Check logs in $logs." }
        try {
            $health = Invoke-RestMethod 'http://127.0.0.1:5001/api/health' -TimeoutSec 2
            $site = Invoke-WebRequest 'http://127.0.0.1:5180' -TimeoutSec 2 -UseBasicParsing
            if ($health.redis -eq 'connected' -and $site.StatusCode -eq 200) { $ready = $true; break }
        } catch [System.Net.WebException] {
            if ($attempt -eq 29) { throw }
        } catch [System.Net.Http.HttpRequestException] {
            if ($attempt -eq 29) { throw }
        }
    }
    if (-not $ready) { throw 'Exortal did not become ready in time.' }
    Write-Host 'Exortal is running at http://127.0.0.1:5180'
    Write-Host "Login details: $instance\local-credentials.json"
    Write-Host "Logs: $logs"
    if ($OpenBrowser) { Start-Process 'http://127.0.0.1:5180' }
} catch {
    foreach ($service in $services) { Stop-Process -Id $service.pid -ErrorAction SilentlyContinue }
    throw
}
