import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

const proxy = { "/api": { target: "http://127.0.0.1:5001", changeOrigin: true } };
export default defineConfig({
  plugins: [vue()],
  server: { proxy },
  preview: { proxy },
});
