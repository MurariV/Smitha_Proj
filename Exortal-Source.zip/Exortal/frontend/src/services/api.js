import { reactive } from "vue";

export const session = reactive({ user: null, csrf: "", loaded: false });

export async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(`/api${path}`, {
      credentials: "same-origin",
      ...options,
      headers: {
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(session.csrf ? { "X-CSRF-TOKEN": session.csrf } : {}),
        ...options.headers,
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new Error("Cannot connect to Exortal. Check that the backend is running, then retry.");
  }
  if (!response.ok) {
    const payload = await response.json().catch(() => ({ message: `Server returned HTTP ${response.status}.` }));
    if (response.status === 401 && path !== "/login") {
      session.user = null;
      session.csrf = "";
      if (path !== "/session") window.dispatchEvent(new Event("exortal:session-expired"));
    }
    const error = new Error(payload.message || payload.msg || "The request could not be completed.");
    error.status = response.status;
    throw error;
  }
  return options.download ? response.blob() : response.json();
}

export async function restoreSession() {
  try {
    const result = await api("/session");
    session.user = result.user;
    session.csrf = result.csrf;
  } catch (error) {
    if (error.status !== 401) throw error;
  }
  session.loaded = true;
}

export function formatDate(value) {
  return value ? new Date(value).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "-";
}

export function toLocalInput(value) {
  if (!value) return "";
  const date = new Date(value);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

export function toISO(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error("Enter all required dates and times.");
  return date.toISOString();
}

export function statusClass(status) {
  if (["Active", "Completed", "Available", "Sent", "Published"].includes(status)) return "text-bg-success";
  if (["Cancelled", "Inactive", "Archived", "Failed"].includes(status)) return "text-bg-danger";
  if (["Booked", "Booking Open", "Submitted"].includes(status)) return "text-bg-primary";
  if (["Full", "Closed", "Slot Creation", "Running", "Queued"].includes(status)) return "text-bg-warning";
  return "text-bg-secondary";
}
