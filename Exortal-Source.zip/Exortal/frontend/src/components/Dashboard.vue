<template>
  <section>
    <div class="page-heading"><h1>{{ role === "Admin" ? "Administration Dashboard" : `${role} Dashboard` }}</h1><RouterLink :to="`${base}/examinations`" class="btn btn-create">{{ role === "Student" ? "View Examinations" : "Manage Examinations" }}</RouterLink></div>
    <div v-if="error" class="alert alert-danger" role="alert">{{ error }} <button class="btn btn-sm btn-outline-danger ms-2" @click="load">Retry</button></div>
    <p v-if="loading" class="loading-text">Loading your dashboard...</p>
    <template v-else>
      <div class="dash row g-3 mb-4">
        <div v-for="(value, key) in data.counts" :key="key" class="col-6 col-md-4 col-xl"><div class="dcard"><h2>{{ label(key) }}</h2><strong>{{ value }}</strong></div></div>
      </div>
      <div class="row g-4">
        <div class="col-xl-6">
          <section class="card h-100">
            <div class="card-header"><div><h2>{{ role === "Student" ? "Available Examinations" : "Examination Dashboard" }}</h2><p>View schedules, rubrics and examination details.</p></div><RouterLink :to="`${base}/examinations`" class="btn btn-create">View All</RouterLink></div>
            <div class="table-responsive"><table class="table drive-table"><thead><tr><th>Examination</th><th>Status</th><th>Action</th></tr></thead><tbody><tr v-for="exam in exams.slice(0, 5)" :key="exam.id"><td><strong>{{ exam.name }}</strong><small class="d-block text-secondary">{{ exam.course_code }} &middot; {{ exam.exam_type }}</small></td><td><span class="badge" :class="statusClass(exam.status)">{{ exam.status }}</span></td><td><RouterLink :to="`${base}/examinations/${exam.id}`" class="btn btn-sm action view">View</RouterLink></td></tr><tr v-if="!exams.length"><td colspan="3" class="empty-text">No examinations available.</td></tr></tbody></table></div>
          </section>
        </div>
        <div class="col-xl-6">
          <section class="card h-100"><div class="card-header"><div><h2>{{ role === "Examiner" ? "Booked Students" : role === "Student" ? "My Bookings" : "Recent Bookings" }}</h2><p>Your latest examination activity.</p></div><RouterLink :to="`${base}/bookings`" class="btn btn-create">View All</RouterLink></div>
            <div class="table-responsive"><table class="table drive-table"><thead><tr><th>{{ role === "Student" ? "Examination" : "Student" }}</th><th>Scheduled</th><th>Status</th></tr></thead><tbody><tr v-for="booking in bookings.slice(0, 5)" :key="booking.id"><td><strong>{{ role === "Student" ? booking.slot.examination : booking.student }}</strong><small v-if="role !== 'Student'" class="d-block text-secondary">{{ booking.slot.examination }}</small></td><td>{{ formatDate(booking.slot.start) }}</td><td><span class="badge" :class="statusClass(booking.status)">{{ booking.status }}</span></td></tr><tr v-if="!bookings.length"><td colspan="3" class="empty-text">No bookings yet.</td></tr></tbody></table></div>
          </section>
        </div>
      </div>
    </template>
  </section>
</template>
<script>
import { api, session, formatDate, statusClass } from "../services/api";
export default {
  data: () => ({ session, data: { counts: {} }, exams: [], bookings: [], loading: true, error: "" }),
  computed: { role() { return session.user.role; }, base() { return `/${this.role.toLowerCase()}`; } },
  mounted() { this.load(); },
  methods: {
    formatDate, statusClass,
    label(value) { return value.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); },
    async load() {
      this.loading = true; this.error = "";
      try {
        const [data, exams, bookings] = await Promise.all([api(`${this.base}/dashboard`), api("/examinations"), api(`${this.base}/bookings`)]);
        this.data = data; this.exams = exams.items; this.bookings = bookings.items;
      } catch (error) { this.error = error.message; }
      finally { this.loading = false; }
    },
  },
};
</script>
