<template>
  <dialog ref="dialog" class="popup-box" aria-labelledby="popup-title" @cancel.prevent="!busy && $emit('close')">
    <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
      <h2 id="popup-title" class="mb-0">{{ title }}</h2>
      <button type="button" class="btn-close mt-2" :disabled="busy" aria-label="Close dialog" @click="$emit('close')"></button>
    </div>
    <slot />
  </dialog>
</template>
<script>
export default {
  props: { title: String, busy: Boolean },
  emits: ["close"],
  mounted() {
    this.opener = document.activeElement;
    this.$refs.dialog.showModal();
    this.$refs.dialog.querySelector("input, textarea, select")?.focus();
  },
  beforeUnmount() {
    this.$refs.dialog.close();
    if (this.opener?.isConnected) this.opener.focus();
  },
};
</script>
