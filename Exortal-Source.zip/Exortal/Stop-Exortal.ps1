$ErrorActionPreference = 'Stop'
$instance = if ($env:EXORTAL_INSTANCE_PATH) { $env:EXORTAL_INSTANCE_PATH } else { Join-Path $PSScriptRoot 'backend\instance' }
$stateFile = Join-Path $instance 'services.json'
if (-not (Test-Path $stateFile)) { Write-Host 'No tracked Exortal services.'; return }
$services = @(Get-Content $stateFile -Raw | ConvertFrom-Json)
foreach ($service in ($services | Sort-Object { $_.name -eq 'redis' })) {
    $process = Get-Process -Id $service.pid -ErrorAction SilentlyContinue
    if ($process -and $process.StartTime.ToUniversalTime() -eq ([datetime]$service.started).ToUniversalTime()) {
        Stop-Process -Id $service.pid
        Write-Host "Stopped $($service.name)."
    }
}
Remove-Item -LiteralPath $stateFile
