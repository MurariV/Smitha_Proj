$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Join-Path $env:USERPROFILE '.local\exortal-tools\python\python.exe'
if (-not (Test-Path $python)) {
    $python = (Get-Command python -ErrorAction Stop).Source
}
if (-not (Test-Path '.venv\Scripts\python.exe')) {
    & $python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 or newer, then retry.' }
}
& '.\.venv\Scripts\python.exe' -m pip install -r '.\backend\requirements.txt'
if ($LASTEXITCODE -ne 0) { throw 'Backend dependency installation failed.' }
$nodeDirectory = Join-Path $env:USERPROFILE '.local\exortal-tools\node'
if (Test-Path (Join-Path $nodeDirectory 'node.exe')) { $env:PATH = "$nodeDirectory;$env:PATH" }
Push-Location frontend
try {
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed. Node.js 22.12+ or 24+ is required.' }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
} finally { Pop-Location }
Push-Location backend
try {
    & '..\.venv\Scripts\python.exe' app.py --init-db
    if ($LASTEXITCODE -ne 0) { throw 'Database initialization failed.' }
} finally { Pop-Location }
Write-Host 'Exortal is ready. Run .\Start-Exortal.ps1.'
