import json
from flask import current_app
from redis import Redis, RedisError


def redis_client():
    return Redis.from_url(current_app.config["REDIS_URL"], decode_responses=True,
                          socket_connect_timeout=1, socket_timeout=1)


def cached(key, producer, ttl=60):
    if current_app.config.get("TESTING"):
        return producer()
    try:
        client = redis_client()
        version = client.get("exortal:version") or "0"
        full_key = f"exortal:{version}:{key}"
        saved = client.get(full_key)
        if saved is not None:
            return json.loads(saved)
        value = producer()
        client.setex(full_key, ttl, json.dumps(value))
        return value
    except (RedisError, json.JSONDecodeError):
        current_app.logger.warning("Redis cache unavailable; serving authoritative SQLite data.", exc_info=True)
        return producer()


def invalidate():
    if not current_app.config.get("TESTING"):
        try:
            redis_client().incr("exortal:version")
        except RedisError:
            current_app.logger.warning("Cache invalidation failed; cached entries expire within 60 seconds.", exc_info=True)
