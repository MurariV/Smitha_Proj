import json
import redis
from flask import current_app

redis_client = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True,
    socket_connect_timeout=1,
    socket_timeout=1,
)


def get_cached_data(key):
    if current_app.config.get("TESTING"):
        return None
    try:
        value = redis_client.get(f"exortal:{key}")
        return json.loads(value) if value is not None else None
    except (redis.RedisError, json.JSONDecodeError):
        current_app.logger.warning("Cache read failed; using database data.", exc_info=True)
        return None


def cache_data(key, data):
    if current_app.config.get("TESTING"):
        return
    try:
        redis_client.setex(f"exortal:{key}", 120, json.dumps(data))
    except redis.RedisError:
        current_app.logger.warning("Cache write failed.", exc_info=True)


def invalidate():
    if current_app.config.get("TESTING"):
        return
    try:
        for key in redis_client.scan_iter(match="exortal:*"):
            redis_client.delete(key)
    except redis.RedisError:
        current_app.logger.warning("Cache clear failed; entries expire after 120 seconds.", exc_info=True)
