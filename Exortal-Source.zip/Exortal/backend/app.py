import os
from pathlib import Path
from flask import Flask, request
from flask_cors import CORS
from sqlalchemy.exc import IntegrityError, OperationalError
from werkzeug.exceptions import HTTPException
from werkzeug.security import generate_password_hash
from model import User, db


def create_app(config=None):
    app = Flask(__name__, instance_relative_config=True, instance_path=os.getenv("EXORTAL_INSTANCE_PATH"))
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    app.config.update(
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", "sqlite:///exortal.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SECRET_KEY=os.getenv("EXORTAL_SECRET_KEY", "ExortalSessionKey"),
        SESSION_PERMANENT=False,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        MAX_CONTENT_LENGTH=1024 * 1024,
        MAIL_MODE=os.getenv("MAIL_MODE", "outbox"),
        SMTP_HOST=os.getenv("SMTP_HOST", ""), SMTP_PORT=int(os.getenv("SMTP_PORT", "587")),
        SMTP_USERNAME=os.getenv("SMTP_USERNAME", ""), SMTP_PASSWORD=os.getenv("SMTP_PASSWORD", ""),
        SMTP_SENDER=os.getenv("SMTP_SENDER", "exortal@localhost"),
        SMTP_TLS=os.getenv("SMTP_TLS", "1") == "1",
        INSTITUTION_TIMEZONE=os.getenv("INSTITUTION_TIMEZONE", "Asia/Kolkata"),
    )
    if config:
        app.config.update(config)
    db.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": ["http://localhost:5173", "http://127.0.0.1:5173"]}},
         supports_credentials=True)
    from routes.auth import auth
    from routes.admin import admin
    from routes.examiner import examiner
    from routes.student import student
    from routes.common import common
    for blueprint in (auth, admin, examiner, student, common):
        app.register_blueprint(blueprint)

    @app.before_request
    def same_origin():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("Origin")
            allowed = {request.host_url.rstrip("/"), "http://localhost:5173", "http://127.0.0.1:5173"}
            if origin and origin not in allowed:
                return {"message": "Cross-origin write requests are not allowed."}, 403

    @app.after_request
    def response_headers(response):
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        db.session.rollback()
        return {"message": error.description}, error.code

    @app.errorhandler(IntegrityError)
    def integrity_error(error):
        db.session.rollback()
        app.logger.warning("Database constraint rejected request: %s", error.orig)
        return {"message": "This change conflicts with an existing record. Check unique email, roll number, course code, or booking."}, 409

    @app.errorhandler(OperationalError)
    def database_error(error):
        db.session.rollback()
        app.logger.exception("SQLite operation failed.")
        return {"message": "The database is busy or unavailable. Please retry."}, 503

    @app.errorhandler(Exception)
    def unexpected(error):
        db.session.rollback()
        app.logger.exception("Unhandled application error.")
        return {"message": "Unable to complete the request."}, 500

    with app.app_context():
        db.create_all()
        if not db.session.scalar(db.select(User).where(User.role == "Admin")):
            address = os.getenv("EXORTAL_ADMIN_EMAIL", "admin@exam.com")
            password = os.getenv("EXORTAL_ADMIN_PASSWORD", "admin123")
            if not password:
                raise ValueError("EXORTAL_ADMIN_PASSWORD cannot be empty.")
            admin_user = User(email=address, password=generate_password_hash(password), role="Admin")
            db.session.add(admin_user)
            db.session.commit()
    return app


if __name__ == "__main__":
    app = create_app()
    app.run(port=5000)
