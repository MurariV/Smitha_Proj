import os
import secrets
import sqlite3
from datetime import timedelta
from pathlib import Path
from flask import Flask, jsonify, request
from flask_cors import CORS
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError, OperationalError
from werkzeug.exceptions import HTTPException
from werkzeug.security import generate_password_hash
from model import User, db
from routes.extensions import jwt


@event.listens_for(Engine, "connect")
def configure_sqlite(connection, _):
    if isinstance(connection, sqlite3.Connection):
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=15000")
        connection.execute("PRAGMA journal_mode=WAL")


def create_app(config=None):
    app = Flask(__name__, instance_relative_config=True, instance_path=os.getenv("EXORTAL_INSTANCE_PATH"))
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    key_path = Path(app.instance_path) / "secret.key"
    if not key_path.exists():
        try:
            with key_path.open("x", encoding="utf-8") as file:
                file.write(secrets.token_hex(48))
        except FileExistsError:
            pass
    app.config.update(
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", "sqlite:///exortal.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JWT_SECRET_KEY=os.getenv("EXORTAL_SECRET_KEY") or key_path.read_text(encoding="utf-8"),
        JWT_TOKEN_LOCATION=["cookies"], JWT_COOKIE_CSRF_PROTECT=True,
        JWT_ACCESS_COOKIE_PATH="/api", JWT_ACCESS_CSRF_COOKIE_PATH="/",
        JWT_COOKIE_SAMESITE="Lax", JWT_COOKIE_SECURE=os.getenv("COOKIE_SECURE") == "1",
        JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=8),
        REDIS_URL=os.getenv("REDIS_URL", "redis://localhost:6379/0"),
        MAX_CONTENT_LENGTH=1024 * 1024,
        MAIL_MODE=os.getenv("MAIL_MODE", "outbox"),
        SMTP_HOST=os.getenv("SMTP_HOST", ""), SMTP_PORT=int(os.getenv("SMTP_PORT", "587")),
        SMTP_USERNAME=os.getenv("SMTP_USERNAME", ""), SMTP_PASSWORD=os.getenv("SMTP_PASSWORD", ""),
        SMTP_SENDER=os.getenv("SMTP_SENDER", "exortal@localhost"),
        SMTP_TLS=os.getenv("SMTP_TLS", "1") == "1",
        INSTITUTION_TIMEZONE=os.getenv("INSTITUTION_TIMEZONE", "Asia/Kolkata"),
    )
    if config:
        app.config.update(config)
    db.init_app(app)
    jwt.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": ["http://localhost:5173", "http://127.0.0.1:5173"]}},
         supports_credentials=True)
    from routes.auth import auth
    from routes.admin import admin
    from routes.examiner import examiner
    from routes.student import student
    from routes.common import common
    for blueprint in (auth, admin, examiner, student, common):
        app.register_blueprint(blueprint)

    @app.before_request
    def same_origin():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("Origin")
            allowed = {request.host_url.rstrip("/"), "http://localhost:5173", "http://127.0.0.1:5173"}
            if origin and origin not in allowed:
                return {"message": "Cross-origin write requests are not allowed."}, 403

    @app.after_request
    def response_headers(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        return response

    @jwt.unauthorized_loader
    def unauthorized(message):
        return jsonify(message="Please log in. " + message), 401

    @jwt.invalid_token_loader
    def invalid(_):
        return jsonify(message="Session is invalid. Please log in again."), 401

    @jwt.expired_token_loader
    def expired(_, __):
        return jsonify(message="Session expired. Please log in again."), 401

    @app.errorhandler(HTTPException)
    def http_error(error):
        db.session.rollback()
        return {"message": error.description}, error.code

    @app.errorhandler(IntegrityError)
    def integrity_error(error):
        db.session.rollback()
        app.logger.warning("Database constraint rejected request: %s", error.orig)
        return {"message": "This change conflicts with an existing record. Check unique email, roll number, course code, or booking."}, 409

    @app.errorhandler(OperationalError)
    def database_error(error):
        db.session.rollback()
        app.logger.exception("SQLite operation failed.")
        return {"message": "The database is busy or unavailable. Please retry."}, 503

    @app.errorhandler(Exception)
    def unexpected(error):
        db.session.rollback()
        app.logger.exception("Unhandled application error.")
        return {"message": "An unexpected server error occurred. Check the backend log."}, 500

    @app.get("/api/health")
    def health():
        from redis import RedisError
        from redis_client import redis_client
        cache_status = "connected"
        try:
            redis_client().ping()
        except RedisError:
            cache_status = "unavailable"
        return {"application": "Exortal", "database": "SQLite", "redis": cache_status,
                "mail_mode": app.config["MAIL_MODE"], "timezone": app.config["INSTITUTION_TIMEZONE"]}

    with app.app_context():
        db.create_all()
        if not db.session.scalar(db.select(User).where(User.role == "Admin")):
            address = os.getenv("EXORTAL_ADMIN_EMAIL", "admin@exam.com")
            password = os.getenv("EXORTAL_ADMIN_PASSWORD", "admin123")
            if not password:
                raise ValueError("EXORTAL_ADMIN_PASSWORD cannot be empty.")
            admin_user = User(email=address, password=generate_password_hash(password), role="Admin")
            db.session.add(admin_user)
            db.session.commit()
    return app


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--init-db", action="store_true")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()
    application = create_app()
    if args.init_db:
        print("Database initialized. Only the administrator is created automatically.")
    else:
        application.run(host="127.0.0.1", port=args.port, debug=False)
