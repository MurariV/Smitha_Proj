from flask import Blueprint, g, request
from sqlalchemy import func
from werkzeug.exceptions import BadRequest, Conflict, Forbidden
from model import Booking, Examination, Slot, db, now
from routes.extensions import examiner_json, iso, roles
from redis_client import cached

common = Blueprint("common", __name__, url_prefix="/api")


def rubric_json(rubric):
    return {key: getattr(rubric, key) for key in ("id", "name", "maximum_marks", "weightage", "description")}


def exam_json(exam):
    return {
        "id": exam.id, "course_id": exam.course_id, "course": exam.course.name, "course_code": exam.course.code,
        "name": exam.name, "exam_type": exam.exam_type, "duration": exam.duration, "maximum_marks": exam.maximum_marks,
        "status": exam.status, "instructions": exam.instructions, "archived": exam.archived,
        "slot_creation_start": iso(exam.slot_creation_start), "slot_creation_end": iso(exam.slot_creation_end),
        "booking_start": iso(exam.booking_start), "booking_end": iso(exam.booking_end),
        "published_at": iso(exam.published_at), "examiners": [examiner_json(user) for user in exam.examiners],
        "rubrics": [rubric_json(rubric) for rubric in exam.rubrics],
    }


def seat_count(slot):
    return db.session.scalar(db.select(func.count(Booking.id)).where(Booking.slot_id == slot.id, Booking.status != "Cancelled"))


def refresh_slot(slot):
    if slot.status not in ("Cancelled", "Completed"):
        slot.status = "Full" if seat_count(slot) >= slot.capacity else "Available"


def slot_json(slot):
    occupied = seat_count(slot)
    return {
        "id": slot.id, "exam_id": slot.exam_id, "examination": slot.exam.name, "course": slot.exam.course.name,
        "examiner_id": slot.examiner_id, "examiner": slot.examiner.name, "start": iso(slot.start), "end": iso(slot.end),
        "capacity": slot.capacity, "booked": occupied, "available_seats": max(0, slot.capacity - occupied),
        "status": slot.status, "meeting_link": slot.meeting_link, "location": slot.location,
        "booking_end": iso(slot.exam.booking_end), "reschedule_history": slot.reschedule_history,
    }


def booking_json(booking, student_view=False):
    published = booking.slot.exam.published_at is not None
    evaluation = booking.evaluation
    result = {
        "id": booking.id, "student_id": booking.student_id, "student": booking.student.name,
        "roll_number": booking.student.roll_number, "student_email": booking.student.user.email,
        "exam_id": booking.exam_id, "slot_id": booking.slot_id, "status": booking.status,
        "booked_at": iso(booking.booked_at), "completed_at": iso(booking.completed_at),
        "slot": slot_json(booking.slot), "published": published, "evaluation": None,
        "maximum_marks": booking.slot.exam.maximum_marks, "reschedule_history": booking.reschedule_history,
    }
    if evaluation and (not student_view or published):
        result["evaluation"] = {
            "id": evaluation.id, "total_marks": evaluation.total_marks, "remarks": evaluation.remarks,
            "evaluated_at": iso(evaluation.evaluated_at), "examiner_id": evaluation.examiner_id,
            "scores": evaluation.scores,
        }
    return result


def require_rubrics(exam):
    if not exam.rubrics or abs(sum(r.weightage for r in exam.rubrics) - 100) > 0.001:
        raise Conflict("Add an evaluation rubric with weightages totaling 100% first.")


def creation_allowed(exam):
    if exam.archived or exam.course.status != "Active" or exam.status != "Slot Creation" or not exam.slot_creation_start <= now() < exam.slot_creation_end:
        raise Conflict("Examiner slot creation is closed or outside its configured period.")


def booking_allowed(exam):
    if exam.archived or exam.course.status != "Active" or exam.status != "Booking Open" or not exam.booking_start <= now() < exam.booking_end:
        raise Conflict("Student booking is closed or outside its configured period.")


def check_overlap(slot, examiner_id, start, end, student_ids=()):
    examiner_conflict = db.select(Slot).where(
        Slot.examiner_id == examiner_id, Slot.status != "Cancelled", Slot.start < end, Slot.end > start)
    if slot:
        examiner_conflict = examiner_conflict.where(Slot.id != slot.id)
    if db.session.scalar(examiner_conflict):
        raise Conflict("This examiner already has an overlapping examination slot.")
    if student_ids:
        query = db.select(Booking).join(Slot).where(
            Booking.student_id.in_(student_ids), Booking.status != "Cancelled",
            Slot.status != "Cancelled", Slot.start < end, Slot.end > start)
        if slot:
            query = query.where(Slot.id != slot.id)
        if db.session.scalar(query):
            raise Conflict("A student has another booking that overlaps this time.")


@common.get("/examinations")
@roles("Admin", "Examiner", "Student")
def examinations():
    query = db.select(Examination).order_by(Examination.id.desc())
    if g.user.role == "Student":
        query = query.where(Examination.archived.is_(False), Examination.status != "Draft")
    elif g.user.role == "Examiner":
        query = query.where(Examination.examiners.any(id=g.user.examiner.id))
    if request.args.get("q"):
        query = query.where(Examination.name.ilike(f"%{request.args['q']}%"))
    exams = db.session.scalars(query).all()
    # Permission checks are always against SQLite before consulting this cache.
    return {"items": [cached(f"exam:{exam.id}", lambda e=exam: exam_json(e)) for exam in exams]}


@common.get("/examinations/<int:exam_id>/slots")
@roles("Admin", "Examiner", "Student")
def schedule(exam_id):
    exam = db.get_or_404(Examination, exam_id)
    if g.user.role == "Examiner" and g.user.examiner not in exam.examiners:
        raise Forbidden("You are not assigned to this examination.")
    if g.user.role == "Student" and (exam.archived or exam.status == "Draft"):
        raise Forbidden("This examination is not available.")
    return {"items": cached(f"schedule:{exam_id}", lambda: [
        slot_json(slot) for slot in db.session.scalars(db.select(Slot).where(Slot.exam_id == exam_id).order_by(Slot.start))
    ])}


@common.get("/examinations/<int:exam_id>/rubrics")
@roles("Admin", "Examiner", "Student")
def rubrics(exam_id):
    exam = db.get_or_404(Examination, exam_id)
    if g.user.role == "Examiner" and g.user.examiner not in exam.examiners:
        raise Forbidden("This examination is not assigned to you.")
    if g.user.role == "Student" and (exam.archived or exam.status == "Draft"):
        raise Forbidden("This examination is not available.")
    return {"items": cached(f"rubric:{exam_id}", lambda: [rubric_json(r) for r in exam.rubrics])}


def filtered_bookings(query):
    if request.args.get("exam_id"):
        try:
            query = query.where(Booking.exam_id == int(request.args["exam_id"]))
        except ValueError:
            raise BadRequest("Invalid examination ID.") from None
    values = [booking_json(item, g.user.role == "Student") for item in db.session.scalars(query.order_by(Booking.id.desc()))]
    search = request.args.get("q", "").lower()
    return {"items": [item for item in values if not search or search in " ".join([
        str(item["id"]), item["student"], item["roll_number"] or "", item["slot"]["examination"], item["slot"]["examiner"]
    ]).lower()]}
