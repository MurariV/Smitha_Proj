import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from flask import current_app
from kombu.exceptions import OperationalError as BrokerError
from redis import Redis, RedisError
from sqlalchemy import func
from werkzeug.exceptions import ServiceUnavailable
from model import Booking, Evaluation, Slot, Student, User, db, now
from routes.mail import send_email
from routes.worker import celery


def queue_task(task, *args):
    try:
        Redis.from_url(celery.conf.broker_url, socket_connect_timeout=2, socket_timeout=2).ping()
        return task.apply_async(args=args).id
    except (RedisError, BrokerError, OSError):
        current_app.logger.exception("Unable to enqueue background job.")
        raise ServiceUnavailable("Redis/task broker is unavailable. Start Redis and the Celery worker, then retry.") from None


def month_bounds():
    zone = ZoneInfo(current_app.config["INSTITUTION_TIMEZONE"])
    current = datetime.now(zone)
    end = current.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    start = (end - timedelta(days=1)).replace(day=1)
    return start.astimezone(timezone.utc).replace(tzinfo=None), end.astimezone(timezone.utc).replace(tzinfo=None), start.strftime("%B %Y")


def report_data():
    start, end, month = month_bounds()
    evaluations = db.select(Evaluation).where(Evaluation.evaluated_at >= start, Evaluation.evaluated_at < end)
    results = db.session.scalars(evaluations).all()
    workload = {}
    for item in results:
        name = item.examiner.name
        workload[name] = workload.get(name, 0) + 1
    completed = db.session.scalar(db.select(func.count(Booking.id)).where(
        Booking.completed_at >= start, Booking.completed_at < end, Booking.status == "Completed"))
    conducted = db.session.scalar(db.select(func.count(func.distinct(Slot.exam_id))).where(
        Slot.start >= start, Slot.start < end, Slot.status == "Completed"))
    pending = db.session.scalar(db.select(func.count(Booking.id)).join(Slot).where(
        Booking.status == "Booked", Slot.start < end))
    return {"month": month, "examinations_conducted": conducted, "students_evaluated": len({r.booking.student_id for r in results}),
            "completed_bookings": completed, "pending_evaluations": pending,
            "examiner_workload": [{"name": name, "evaluations": count} for name, count in sorted(workload.items(), key=lambda row: -row[1])]}


@celery.task(name="routes.tasks.daily_reminders")
def daily_reminders():
    zone = ZoneInfo(current_app.config["INSTITUTION_TIMEZONE"])
    local = datetime.now(zone)
    start = local.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=2)
    start_utc = start.astimezone(timezone.utc).replace(tzinfo=None)
    end_utc = end.astimezone(timezone.utc).replace(tzinfo=None)
    bookings = db.session.scalars(db.select(Booking).join(Slot).where(
        Booking.status == "Booked", Slot.status.not_in(["Cancelled", "Completed"]),
        Slot.start >= max(start_utc, now()), Slot.start < end_utc)).all()
    sent = 0
    for booking in bookings:
        scheduled = booking.slot.start.replace(tzinfo=timezone.utc).astimezone(zone)
        status = send_email(f"reminder:{local.date()}:{booking.id}:{booking.slot.start.isoformat()}:{booking.slot.examiner_id}",
                           booking.student.user.email, f"Exortal | Reminder: {booking.slot.exam.name}", "reminder.html",
                           student=booking.student, examination=booking.slot.exam, slot=booking.slot,
                           scheduled=scheduled.strftime("%d %B %Y, %I:%M %p %Z"))
        sent += status in ("Sent", "Local outbox")
    return {"reminders": sent}


@celery.task(name="routes.tasks.send_monthly_report")
def send_monthly_report():
    report = report_data()
    administrator = db.session.scalar(db.select(User).where(User.role == "Admin"))
    status = send_email(f"monthly:{report['month']}", administrator.email,
                        f"Exortal | Examination report - {report['month']}", "monthly_report.html", report=report)
    return {"status": status, "month": report["month"]}


def csv_cell(value):
    text = "" if value is None else str(value)
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else text


@celery.task(name="routes.tasks.export_examination_history")
def export_examination_history(student_id, job_id):
    profile = db.session.get(Student, student_id)
    if profile is None or profile.export_task_id != job_id:
        raise ValueError("This history export is no longer associated with the student.")
    if profile.export_status == "Completed":
        return {"id": job_id, "status": profile.export_status}
    profile.export_status = "Running"
    db.session.commit()
    try:
        folder = Path(current_app.instance_path) / "exports"
        folder.mkdir(exist_ok=True)
        path = folder / f"{job_id}.csv"
        temporary = folder / f"{job_id}.tmp"
        zone = ZoneInfo(current_app.config["INSTITUTION_TIMEZONE"])
        bookings = db.session.scalars(db.select(Booking).where(Booking.student_id == student_id).order_by(Booking.id)).all()
        with temporary.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(["Student ID", "Examination Name", "Course", "Examination Date", "Examiner", "Marks Obtained", "Booking Status"])
            for booking in bookings:
                exam = booking.slot.exam
                marks = booking.evaluation.total_marks if exam.published_at and booking.evaluation else ""
                date = booking.slot.start.replace(tzinfo=timezone.utc).astimezone(zone).strftime("%Y-%m-%d %H:%M %Z")
                writer.writerow([csv_cell(v) for v in [booking.student_id, exam.name, exam.course.name, date,
                                                       booking.slot.examiner.name, marks, booking.status]])
        temporary.replace(path)
        profile.export_status, profile.export_error = "Completed", None
        db.session.commit()
        return {"id": job_id, "status": profile.export_status}
    except Exception:
        db.session.rollback()
        profile = db.session.get(Student, student_id)
        profile.export_status, profile.export_error = "Failed", "Export failed. Check the worker log and request another export."
        db.session.commit()
        current_app.logger.exception("Examination history export failed.")
        raise
