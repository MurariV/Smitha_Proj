from flask import Blueprint, g, request
from sqlalchemy import func
from werkzeug.exceptions import BadRequest, Conflict
from werkzeug.security import generate_password_hash
from model import Booking, Course, Examination, Examiner, Rubric, Slot, Student, User, db, now
from redis_client import invalidate
from routes.common import booking_json, check_overlap, exam_json, filtered_bookings, refresh_slot, require_rubrics, seat_count, slot_json
from routes.extensions import atomic, body, email, get_or_404, iso, number, password, roles, string, timestamp, user_json

admin = Blueprint("admin", __name__, url_prefix="/api/admin")
EXAM_TYPES = ("Viva", "Practical", "Project Demo", "Assessment")
EXAM_STATUSES = ("Draft", "Slot Creation", "Booking Open", "Closed", "Completed")


def commit():
    db.session.commit()
    invalidate()


def course_json(course):
    return {key: getattr(course, key) for key in ("id", "code", "name", "description", "status")}


@admin.get("/dashboard")
@roles("Admin")
def dashboard():
    counts = {name: db.session.scalar(db.select(func.count(model.id))) for name, model in (
        ("courses", Course), ("examinations", Examination), ("slots", Slot), ("bookings", Booking))}
    for name, model in (("students", Student), ("examiners", Examiner)):
        counts[name] = db.session.scalar(db.select(func.count(model.id)))
    return {"counts": counts, "recent_bookings": [
        booking_json(b) for b in db.session.scalars(db.select(Booking).order_by(Booking.id.desc()).limit(5))]}


@admin.route("/courses", methods=["GET", "POST"])
@roles("Admin")
def courses():
    if request.method == "GET":
        return {"items": [course_json(c) for c in db.session.scalars(db.select(Course).order_by(Course.id.desc()))]}
    data = body()
    course = Course(code=string(data, "code", 30).upper(), name=string(data, "name", 150),
                    description=string(data, "description", 3000, False))
    db.session.add(course)
    db.session.flush()
    commit()
    return course_json(course), 201


@admin.route("/courses/<int:ident>", methods=["PUT", "DELETE"])
@roles("Admin")
def course_detail(ident):
    atomic()
    course = get_or_404(Course, ident)
    if request.method == "DELETE":
        if db.session.scalar(db.select(Examination).where(Examination.course_id == ident, Examination.archived.is_(False), Examination.status != "Completed")):
            raise Conflict("Complete or archive the course's examinations before archiving this course.")
        course.status = "Archived"
    else:
        data = body()
        course.code = string(data, "code", 30).upper()
        course.name = string(data, "name", 150)
        course.description = string(data, "description", 3000, False)
        if data.get("status") not in ("Active", "Archived"):
            raise BadRequest("Invalid course status.")
        if data["status"] == "Archived" and course.status != "Archived":
            raise BadRequest("Use the Archive action so active examinations can be checked.")
        course.status = data["status"]
    commit()
    return {"message": "Course updated."}


@admin.route("/users", methods=["GET", "POST"])
@roles("Admin")
def users():
    if request.method == "GET":
        role = request.args.get("role", "Student")
        if role not in ("Student", "Examiner"):
            raise BadRequest("Role must be Student or Examiner.")
        profile = Student if role == "Student" else Examiner
        query = db.select(User).join(profile).where(User.role == role).order_by(User.id.desc())
        q = request.args.get("q", "")
        if q:
            matches = profile.name.ilike(f"%{q}%") | User.email.ilike(f"%{q}%")
            if role == "Student":
                matches = matches | Student.roll_number.ilike(f"%{q}%")
            query = query.where(matches)
        return {"items": [user_json(u) for u in db.session.scalars(query)]}
    data = body()
    user = User(role="Examiner", email=email(data), password=generate_password_hash(password(data)))
    user.examiner = Examiner(name=string(data, "name", 120), department=string(data, "department", 100),
                             phone=string(data, "phone", 30))
    db.session.add(user)
    db.session.flush()
    commit()
    return user_json(user), 201


@admin.put("/users/<int:ident>")
@roles("Admin")
def user_detail(ident):
    data = body()
    atomic()
    user = get_or_404(User, ident)
    if user.role == "Admin":
        raise BadRequest("The administrator cannot be removed or deactivated.")
    status = data.get("status")
    if status not in ("Active", "Inactive"):
        raise BadRequest("Invalid account status.")
    if status == "Inactive":
        if user.role == "Examiner":
            pending = db.select(Booking).join(Slot).where(Slot.examiner_id == user.examiner.id, Booking.status == "Booked")
        else:
            pending = db.select(Booking).where(Booking.student_id == user.student.id, Booking.status == "Booked")
        if db.session.scalar(pending):
            raise Conflict("Resolve or reassign this user's active bookings before deactivating the account.")
    profile = user.student if user.role == "Student" else user.examiner
    profile.name = string(data, "name", 120)
    profile.department = string(data, "department", 100)
    profile.phone = string(data, "phone", 30)
    if user.status != status:
        user.token_version += 1
    user.status = status
    commit()
    return user_json(user)


def set_exam(exam, data):
    course = get_or_404(Course, number(data, "course_id", 1, integer=True))
    if course.status != "Active":
        raise Conflict("Choose an active course.")
    exam.course_id = course.id
    exam.name = string(data, "name", 160)
    exam.exam_type = string(data, "exam_type", 30)
    if exam.exam_type not in EXAM_TYPES:
        raise BadRequest("Invalid examination type.")
    exam.duration = number(data, "duration", 5, 480, True)
    exam.maximum_marks = number(data, "maximum_marks", 1, 1000)
    exam.instructions = string(data, "instructions", 5000, False)
    for key in ("slot_creation_start", "slot_creation_end", "booking_start", "booking_end"):
        setattr(exam, key, timestamp(data, key))
    if not exam.slot_creation_start < exam.slot_creation_end <= exam.booking_start < exam.booking_end:
        raise BadRequest("Timeline must be: slot creation start < end <= booking start < end.")
    ids = data.get("examiner_ids")
    if not isinstance(ids, list) or not ids or any(type(i) is not int for i in ids):
        raise BadRequest("Assign at least one examiner.")
    examiners = db.session.scalars(db.select(Examiner).join(User).where(Examiner.id.in_(ids), User.role == "Examiner", User.status == "Active")).all()
    if len(examiners) != len(set(ids)):
        raise BadRequest("All assigned examiners must be active examiner accounts.")
    if exam.id:
        slots = db.session.scalars(db.select(Slot).where(Slot.exam_id == exam.id, Slot.status != "Cancelled")).all()
        if any(s.examiner_id not in ids for s in slots):
            raise Conflict("Reassign or remove an examiner's slots before removing their assignment.")
        if any(s.start < exam.booking_end or (s.end - s.start).total_seconds() != exam.duration * 60 for s in slots):
            raise Conflict("The new timeline or duration conflicts with existing slots.")
    exam.examiners = examiners


@admin.post("/examinations")
@roles("Admin")
def create_exam():
    exam = Examination()
    set_exam(exam, body())
    db.session.add(exam)
    db.session.flush()
    commit()
    return exam_json(exam), 201


@admin.route("/examinations/<int:ident>", methods=["PUT", "DELETE"])
@roles("Admin")
def update_exam(ident):
    atomic()
    exam = get_or_404(Examination, ident)
    if request.method == "DELETE":
        if db.session.scalar(db.select(Booking).where(Booking.exam_id == ident, Booking.status == "Booked")):
            raise Conflict("Resolve active bookings before archiving an examination.")
        exam.archived = True
    else:
        if exam.published_at or db.session.scalar(db.select(Booking).where(Booking.exam_id == ident)):
            raise Conflict("Booked examinations are protected. Use slot rescheduling or examiner reassignment for exceptions.")
        set_exam(exam, body())
    commit()
    return {"message": "Examination updated."}


@admin.post("/examinations/<int:ident>/status")
@roles("Admin")
def exam_status(ident):
    atomic()
    exam = get_or_404(Examination, ident)
    status = string(body(), "status", 30)
    if status not in EXAM_STATUSES or exam.archived or exam.published_at:
        raise BadRequest("This examination cannot be changed to that status.")
    if status == "Slot Creation" and not exam.slot_creation_start <= now() < exam.slot_creation_end:
        raise Conflict("The configured slot creation period is not currently active.")
    if status == "Booking Open":
        if not exam.booking_start <= now() < exam.booking_end:
            raise Conflict("The configured student booking period is not currently active.")
        require_rubrics(exam)
    if status == "Completed":
        if db.session.scalar(db.select(Booking).where(Booking.exam_id == ident, Booking.status == "Booked")):
            raise Conflict("All booked students must be evaluated before completing the examination.")
        for slot in db.session.scalars(db.select(Slot).where(Slot.exam_id == ident, Slot.status != "Cancelled")):
            slot.status = "Completed"
    if status in ("Draft", "Slot Creation") and db.session.scalar(db.select(Booking).where(Booking.exam_id == ident, Booking.status != "Cancelled")):
        raise Conflict("An examination with bookings cannot return to draft or slot creation.")
    exam.status = status
    commit()
    return {"message": f"Examination is now {status}."}


@admin.put("/examinations/<int:ident>/rubrics")
@roles("Admin")
def update_rubrics(ident):
    atomic()
    exam = get_or_404(Examination, ident)
    if exam.published_at or db.session.scalar(db.select(Booking).where(Booking.exam_id == ident)):
        raise Conflict("Rubrics are locked after the first booking to preserve assessment history.")
    criteria = body().get("criteria")
    if not isinstance(criteria, list) or not 1 <= len(criteria) <= 30:
        raise BadRequest("Provide between 1 and 30 rubric criteria.")
    rows = []
    for row in criteria:
        if not isinstance(row, dict):
            raise BadRequest("Invalid rubric criterion.")
        rows.append(Rubric(name=string(row, "name", 120), maximum_marks=number(row, "maximum_marks", 1, 1000),
                           weightage=number(row, "weightage", 0.01, 100), description=string(row, "description", 1000, False)))
    if abs(sum(row.weightage for row in rows) - 100) > 0.001:
        raise BadRequest("Rubric weightages must total exactly 100%.")
    exam.rubrics = rows
    commit()
    return {"message": "Rubric saved."}


@admin.get("/slots")
@roles("Admin")
def slots():
    return {"items": [slot_json(s) for s in db.session.scalars(db.select(Slot).order_by(Slot.start.desc()))]}


@admin.put("/slots/<int:ident>")
@roles("Admin")
def reschedule_slot(ident):
    data = body()
    reason = string(data, "reason", 1000)
    atomic()
    slot = get_or_404(Slot, ident)
    if slot.status in ("Completed", "Cancelled") or slot.exam.published_at or any(b.evaluation for b in slot.bookings):
        raise Conflict("Cancelled, completed, or evaluated slots cannot be changed.")
    start, end = timestamp(data, "start"), timestamp(data, "end")
    examiner = get_or_404(Examiner, number(data, "examiner_id", 1, integer=True))
    capacity = number(data, "capacity", 1, 500, True)
    if examiner.user.status != "Active" or examiner not in slot.exam.examiners:
        raise BadRequest("Choose an active examiner assigned to this examination.")
    if start <= now() or start < slot.exam.booking_end or (end - start).total_seconds() != slot.exam.duration * 60:
        raise BadRequest("Slot must be in the future, after booking closes, and match the examination duration.")
    if capacity < seat_count(slot):
        raise Conflict("Capacity cannot be below the number of booked students.")
    check_overlap(slot, examiner.id, start, end, [b.student_id for b in slot.bookings if b.status != "Cancelled"])
    previous = {"start": iso(slot.start), "end": iso(slot.end), "examiner_id": slot.examiner_id, "capacity": slot.capacity}
    slot.start, slot.end, slot.examiner_id, slot.capacity = start, end, examiner.id, capacity
    slot.meeting_link = string(data, "meeting_link", 500, False)
    if slot.meeting_link and not slot.meeting_link.startswith(("https://", "http://")):
        raise BadRequest("Meeting link must begin with https:// or http://.")
    slot.location = string(data, "location", 200, False)
    refresh_slot(slot)
    slot.reschedule_history = slot.reschedule_history + [{
        "changed_at": iso(now()), "reason": reason, "previous": previous,
        "updated": {"start": iso(start), "end": iso(end), "examiner_id": examiner.id, "capacity": capacity},
    }]
    commit()
    return {"message": "Slot updated."}


@admin.get("/bookings")
@roles("Admin")
def bookings():
    return filtered_bookings(db.select(Booking))


@admin.post("/bookings/<int:ident>/reschedule")
@roles("Admin")
def reschedule_booking(ident):
    data = body()
    reason = string(data, "reason", 1000)
    atomic()
    booking = get_or_404(Booking, ident)
    target = get_or_404(Slot, number(data, "slot_id", 1, integer=True))
    if booking.status != "Booked" or booking.evaluation or booking.slot.exam.published_at:
        raise Conflict("Only pending, unevaluated bookings may be rescheduled.")
    if target.id == booking.slot_id or target.exam_id != booking.exam_id:
        raise BadRequest("Choose a different slot in the same examination.")
    if target.status not in ("Available", "Full") or target.start <= now() or target.examiner.user.status != "Active" or seat_count(target) >= target.capacity:
        raise Conflict("The target slot is unavailable or full.")
    overlap = db.select(Booking).join(Slot).where(
        Booking.student_id == booking.student_id, Booking.id != booking.id, Booking.status != "Cancelled",
        Slot.start < target.end, Slot.end > target.start)
    if db.session.scalar(overlap):
        raise Conflict("The student has an overlapping booking.")
    old = booking.slot
    booking.slot = target
    db.session.flush()
    refresh_slot(old)
    refresh_slot(target)
    booking.reschedule_history = booking.reschedule_history + [{
        "changed_at": iso(now()), "previous_slot_id": old.id, "slot_id": target.id, "reason": reason,
    }]
    commit()
    return {"message": "Booking rescheduled."}


@admin.post("/examinations/<int:ident>/publish")
@roles("Admin")
def publish(ident):
    atomic()
    exam = get_or_404(Examination, ident)
    if exam.status != "Completed" or exam.published_at:
        raise Conflict("Complete the examination before publishing. Already published results cannot be republished.")
    completed = db.session.scalars(db.select(Booking).where(Booking.exam_id == ident, Booking.status == "Completed")).all()
    if not completed or any(not b.evaluation for b in completed):
        raise Conflict("This examination does not have a complete set of evaluations.")
    exam.published_at = now()
    commit()
    return {"message": "Results published."}


@admin.get("/reports")
@roles("Admin")
def reports():
    from routes.tasks import report_data
    return report_data()


@admin.post("/reports/monthly")
@roles("Admin")
def queue_report():
    from routes.tasks import queue_task, send_monthly_report
    task_id = queue_task(send_monthly_report)
    return {"message": "Monthly report queued.", "task_id": task_id}, 202
