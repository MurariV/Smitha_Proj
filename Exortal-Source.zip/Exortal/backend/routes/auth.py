from flask import Blueprint, g, request, session
from werkzeug.exceptions import Conflict, Unauthorized
from werkzeug.security import check_password_hash, generate_password_hash
from model import Student, User, db
from routes.extensions import body, email, password, roles, string, user_json

auth = Blueprint("auth", __name__, url_prefix="/api")


@auth.post("/login")
def login():
    data = body()
    user = User.query.filter_by(email=email(data)).first()
    candidate = password(data)
    if not user or not check_password_hash(user.password, candidate) or user.status != "Active":
        raise Unauthorized("Invalid email/password, or the account is inactive.")
    session.clear()
    session["user_id"] = user.id
    session["role"] = user.role
    session.permanent = False
    return {"user": user_json(user)}


@auth.post("/student/register")
def register():
    data = body()
    address = email(data)
    roll = string(data, "roll_number", 40).upper()
    if db.session.scalar(db.select(User).where(User.email == address)) or db.session.scalar(db.select(Student).where(Student.roll_number == roll)):
        raise Conflict("Email address or roll number is already registered.")
    user = User(email=address, password=generate_password_hash(password(data)), role="Student")
    user.student = Student(name=string(data, "name", 120), department=string(data, "department", 100),
                           phone=string(data, "phone", 30), roll_number=roll)
    db.session.add(user)
    db.session.commit()
    return {"message": "Registration successful. Please log in."}, 201


@auth.get("/session")
@roles()
def session_check():
    return {"user": user_json(g.user)}


@auth.post("/logout")
@roles()
def logout():
    session.clear()
    return {"message": "Logged out."}


@auth.route("/profile", methods=["GET", "PUT"])
@roles("Student")
def profile():
    if request.method == "PUT":
        data = body()
        g.user.student.name = string(data, "name", 120)
        g.user.student.department = string(data, "department", 100)
        g.user.student.phone = string(data, "phone", 30)
        db.session.commit()
    return {"user": user_json(g.user)}
