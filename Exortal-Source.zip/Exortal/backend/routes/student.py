from pathlib import Path
from uuid import uuid4
from flask import Blueprint, current_app, g, send_file
from werkzeug.exceptions import Conflict, Forbidden, ServiceUnavailable
from model import Booking, Examination, Slot, db, now
from redis_client import invalidate
from routes.common import booking_allowed, booking_json, filtered_bookings, refresh_slot, require_rubrics, seat_count
from routes.extensions import atomic, body, get_or_404, number, roles

student = Blueprint("student", __name__, url_prefix="/api/student")


@student.get("/dashboard")
@roles("Student")
def dashboard():
    bookings = db.session.scalars(db.select(Booking).where(Booking.student_id == g.user.student.id)).all()
    open_exams = db.session.scalars(db.select(Examination).where(
        Examination.archived.is_(False), Examination.status == "Booking Open",
        Examination.booking_start <= now(), Examination.booking_end > now())).all()
    slots = db.session.scalars(db.select(Slot).where(Slot.exam_id.in_([e.id for e in open_exams]), Slot.status == "Available", Slot.start > now())).all()
    return {"counts": {"available_examinations": len(open_exams),
                       "available_slots": sum(s.examiner.user.status == "Active" and seat_count(s) < s.capacity for s in slots),
                       "upcoming_examinations": sum(b.status == "Booked" and b.slot.start > now() for b in bookings),
                       "booked_slots": sum(b.status == "Booked" for b in bookings),
                       "published_results": sum(b.status == "Completed" and b.slot.exam.published_at is not None for b in bookings)},
            "bookings": [booking_json(b, True) for b in bookings]}


@student.post("/bookings")
@roles("Student")
def book():
    data = body()
    atomic()
    slot = get_or_404(Slot, number(data, "slot_id", 1, integer=True))
    booking_allowed(slot.exam)
    require_rubrics(slot.exam)
    if slot.examiner.user.status != "Active" or slot.status not in ("Available", "Full") or slot.start <= now():
        raise Conflict("This examination slot is not available.")
    if db.session.scalar(db.select(Booking).where(Booking.student_id == g.user.student.id, Booking.exam_id == slot.exam_id, Booking.status != "Cancelled")):
        raise Conflict("You already have a booking for this examination.")
    if seat_count(slot) >= slot.capacity:
        raise Conflict("This slot is full. Choose another slot.")
    overlap = db.select(Booking).join(Slot).where(
        Booking.student_id == g.user.student.id, Booking.status != "Cancelled", Slot.start < slot.end, Slot.end > slot.start)
    if db.session.scalar(overlap):
        raise Conflict("You already have a booking that overlaps this time.")
    booking = Booking(student_id=g.user.student.id, exam_id=slot.exam_id, slot=slot)
    db.session.add(booking)
    db.session.flush()
    refresh_slot(slot)
    db.session.commit()
    invalidate()
    return booking_json(booking, True), 201


@student.post("/bookings/<int:ident>/cancel")
@roles("Student")
def cancel(ident):
    atomic()
    booking = get_or_404(Booking, ident)
    if booking.student_id != g.user.student.id:
        raise Forbidden("This booking does not belong to you.")
    if booking.status != "Booked" or now() >= booking.slot.exam.booking_end or now() >= booking.slot.start:
        raise Conflict("Bookings can be cancelled only before the booking deadline and examination start.")
    booking.status = "Cancelled"
    db.session.flush()
    refresh_slot(booking.slot)
    db.session.commit()
    invalidate()
    return {"message": "Booking cancelled. The seat is available again."}


@student.get("/bookings")
@student.get("/history")
@roles("Student")
def history():
    return filtered_bookings(db.select(Booking).where(Booking.student_id == g.user.student.id))


@student.post("/exports")
@roles("Student")
def create_export():
    from routes.tasks import export_examination_history, queue_task
    atomic()
    profile = g.user.student
    if profile.export_status in ("Queued", "Running"):
        raise Conflict("Your history export is already being prepared.")
    profile.export_task_id = str(uuid4())
    profile.export_status, profile.export_error = "Queued", None
    db.session.commit()
    try:
        queue_task(export_examination_history, profile.id, profile.export_task_id)
    except ServiceUnavailable:
        profile.export_status, profile.export_error = "Failed", "The background job could not be queued. Please retry."
        db.session.commit()
        raise
    return {"id": profile.export_task_id, "status": profile.export_status}, 202


@student.get("/exports")
@roles("Student")
def exports():
    profile = g.user.student
    return {"items": [{"id": profile.export_task_id, "status": profile.export_status, "error": profile.export_error}]
            if profile.export_task_id else []}


@student.get("/exports/<string:ident>/download")
@roles("Student")
def download(ident):
    profile = g.user.student
    if profile.export_task_id != ident:
        raise Forbidden("This export does not belong to you.")
    if profile.export_status != "Completed":
        raise Conflict("This export is not ready. Check its status and try again.")
    path = Path(current_app.instance_path) / "exports" / f"{ident}.csv"
    if not path.is_file():
        raise Conflict("The export file is missing. Request a new export.")
    return send_file(path, as_attachment=True, download_name="Exortal-examination-history.csv", mimetype="text/csv")
