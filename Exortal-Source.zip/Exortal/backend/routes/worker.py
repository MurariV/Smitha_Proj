import os
from functools import lru_cache
from celery import Celery, Task
from celery.schedules import crontab


@lru_cache(maxsize=1)
def task_app():
    from app import create_app
    return create_app()


class FlaskTask(Task):
    def __call__(self, *args, **kwargs):
        with task_app().app_context():
            return self.run(*args, **kwargs)


celery = Celery(
    "Exortal", task_cls=FlaskTask,
    broker=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/1"),
    backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/2"),
    include=["routes.tasks"],
)
celery.conf.update(
    timezone=os.getenv("INSTITUTION_TIMEZONE", "Asia/Kolkata"),
    enable_utc=True, task_serializer="json", result_serializer="json", accept_content=["json"],
    result_expires=86400, broker_connection_retry_on_startup=True,
    broker_connection_timeout=3, task_publish_retry=False,
    beat_schedule={
        "daily-examination-reminders": {"task": "routes.tasks.daily_reminders", "schedule": crontab(hour=9, minute=0)},
        "monthly-examination-report": {"task": "routes.tasks.send_monthly_report", "schedule": crontab(day_of_month=1, hour=9, minute=0)},
    },
)
