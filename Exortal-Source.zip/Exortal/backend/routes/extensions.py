import math
import re
from datetime import datetime, timezone
from functools import wraps
from flask import g, request
from flask_jwt_extended import JWTManager, get_jwt, get_jwt_identity, verify_jwt_in_request
from sqlalchemy import text
from werkzeug.exceptions import BadRequest, Forbidden, NotFound, Unauthorized
from model import User, db

jwt = JWTManager()


def roles(*allowed):
    def decorator(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            verify_jwt_in_request()
            user = db.session.get(User, int(get_jwt_identity()))
            if not user or user.status != "Active" or user.token_version != get_jwt().get("version"):
                raise Unauthorized("Your account is inactive or this session has expired.")
            if allowed and user.role not in allowed:
                raise Forbidden("You do not have permission to perform this action.")
            if (user.role == "Student" and user.student is None) or (user.role == "Examiner" and user.examiner is None):
                raise Unauthorized("The account does not have its required profile.")
            g.user = user
            return function(*args, **kwargs)
        return wrapped
    return decorator


def body():
    value = request.get_json()
    if not isinstance(value, dict):
        raise BadRequest("A JSON object is required.")
    return value


def string(data, key, maximum=200, required=True):
    value = data.get(key, "")
    if not isinstance(value, str) or len(value.strip()) > maximum or (required and not value.strip()):
        raise BadRequest(f"{key.replace('_', ' ').capitalize()} is required and must be at most {maximum} characters.")
    return value.strip()


def number(data, key, minimum=0, maximum=10000, integer=False):
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise BadRequest(f"{key} must be a valid number.")
    if not minimum <= value <= maximum or (integer and value != int(value)):
        raise BadRequest(f"{key} must be {'an integer ' if integer else ''}between {minimum} and {maximum}.")
    return int(value) if integer else float(value)


def timestamp(data, key):
    try:
        value = datetime.fromisoformat(string(data, key, 40).replace("Z", "+00:00"))
        if value.tzinfo is None:
            raise ValueError()
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    except ValueError:
        raise BadRequest(f"{key} must be a valid ISO date/time with timezone.") from None


def email(data):
    value = string(data, "email", 254).lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value):
        raise BadRequest("Enter a valid email address.")
    return value


def password(data):
    value = data.get("password")
    if not isinstance(value, str) or not value:
        raise BadRequest("Password is required.")
    return value


def get_or_404(model, ident):
    obj = db.session.get(model, ident)
    if obj is None:
        raise NotFound(f"{model.__name__} not found.")
    return obj


def atomic():
    # SQLite's write reservation serializes capacity checks with the booking write.
    actor_id = g.user.id
    db.session.rollback()
    db.session.execute(text("BEGIN IMMEDIATE"))
    g.user = db.session.get(User, actor_id)
    if not g.user or g.user.status != "Active" or g.user.token_version != get_jwt().get("version"):
        raise Unauthorized("Your account or session became inactive. Please log in again.")


def iso(value):
    return value.isoformat(timespec="seconds") + "Z" if value else None


def user_json(user):
    profile = user.student if user.role == "Student" else user.examiner
    return {
        "id": user.id, "email": user.email, "role": user.role, "status": user.status,
        "name": profile.name if profile else "Administrator",
        "department": profile.department if profile else "", "phone": profile.phone if profile else "",
        "student_id": user.student.id if user.student else None,
        "examiner_id": user.examiner.id if user.examiner else None,
        "roll_number": user.student.roll_number if user.student else None,
    }


def examiner_json(examiner):
    return {"id": examiner.id, "user_id": examiner.user_id, "name": examiner.name,
            "department": examiner.department, "phone": examiner.phone,
            "email": examiner.user.email, "status": examiner.user.status}
