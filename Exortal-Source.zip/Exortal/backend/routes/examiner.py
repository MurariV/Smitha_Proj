from flask import Blueprint, g, request
from sqlalchemy import func
from werkzeug.exceptions import BadRequest, Conflict, Forbidden
from model import Booking, Evaluation, Examination, Slot, db, now
from redis_client import invalidate
from routes.common import check_overlap, creation_allowed, exam_json, filtered_bookings, require_rubrics, slot_json
from routes.extensions import atomic, body, get_or_404, number, roles, string, timestamp

examiner = Blueprint("examiner", __name__, url_prefix="/api/examiner")


@examiner.get("/dashboard")
@roles("Examiner")
def dashboard():
    exams = db.session.scalars(db.select(Examination).where(Examination.examiners.any(id=g.user.examiner.id))).all()
    slots = db.session.scalars(db.select(Slot).where(Slot.examiner_id == g.user.examiner.id)).all()
    bookings = db.session.scalars(db.select(Booking).join(Slot).where(Slot.examiner_id == g.user.examiner.id, Booking.status != "Cancelled")).all()
    return {"counts": {"assigned_examinations": len(exams), "created_slots": len(slots), "booked_students": len(bookings),
                       "pending_evaluations": sum(b.status == "Booked" and b.slot.start <= now() for b in bookings)},
            "examinations": [exam_json(exam) for exam in exams]}


def owned_slot(ident):
    slot = get_or_404(Slot, ident)
    if slot.examiner_id != g.user.examiner.id:
        raise Forbidden("You can manage only your own examination slots.")
    return slot


def fill_slot(slot, data):
    start, end = timestamp(data, "start"), timestamp(data, "end")
    if start <= now() or start < slot.exam.booking_end or (end - start).total_seconds() != slot.exam.duration * 60:
        raise BadRequest("Slot must be in the future, after booking closes, and match the examination duration.")
    check_overlap(slot if slot.id else None, g.user.examiner.id, start, end)
    slot.start, slot.end = start, end
    slot.capacity = number(data, "capacity", 1, 500, True)
    slot.location = string(data, "location", 200, False)
    slot.meeting_link = string(data, "meeting_link", 500, False)
    if slot.meeting_link and not slot.meeting_link.startswith(("https://", "http://")):
        raise BadRequest("Use an http:// or https:// meeting link.")


@examiner.route("/slots", methods=["GET", "POST"])
@roles("Examiner")
def slots():
    if request.method == "GET":
        return {"items": [slot_json(s) for s in db.session.scalars(db.select(Slot).where(Slot.examiner_id == g.user.examiner.id).order_by(Slot.start))]}
    data = body()
    atomic()
    exam = get_or_404(Examination, number(data, "exam_id", 1, integer=True))
    if g.user.examiner not in exam.examiners:
        raise Forbidden("You are not assigned to this examination.")
    creation_allowed(exam)
    slot = Slot(exam=exam, examiner_id=g.user.examiner.id)
    fill_slot(slot, data)
    db.session.add(slot)
    db.session.flush()
    db.session.commit()
    invalidate()
    return slot_json(slot), 201


@examiner.route("/slots/<int:ident>", methods=["PUT", "DELETE"])
@roles("Examiner")
def slot_detail(ident):
    atomic()
    slot = owned_slot(ident)
    creation_allowed(slot.exam)
    if now() >= slot.exam.booking_start or slot.bookings or slot.status in ("Cancelled", "Completed"):
        raise Conflict("Slots can be changed only before student booking starts and before any booking is made.")
    if request.method == "DELETE":
        slot.status = "Cancelled"
    else:
        fill_slot(slot, body())
    db.session.commit()
    invalidate()
    return {"message": "Slot updated."}


@examiner.get("/bookings")
@roles("Examiner")
def bookings():
    return filtered_bookings(db.select(Booking).join(Slot).where(Slot.examiner_id == g.user.examiner.id))


@examiner.post("/bookings/<int:ident>/evaluate")
@roles("Examiner")
def evaluate(ident):
    data = body()
    atomic()
    booking = get_or_404(Booking, ident)
    if booking.slot.examiner_id != g.user.examiner.id:
        raise Forbidden("You may evaluate only students booked into your own slots.")
    if booking.status != "Booked" or booking.evaluation or booking.slot.status in ("Cancelled", "Completed"):
        raise Conflict("This booking cannot be evaluated or has already been submitted.")
    if booking.slot.start > now():
        raise Conflict("Evaluation can begin only when the examination slot starts.")
    exam = booking.slot.exam
    if exam.published_at:
        raise Conflict("Published results are immutable.")
    require_rubrics(exam)
    scores = data.get("scores")
    if not isinstance(scores, list) or any(not isinstance(s, dict) for s in scores):
        raise BadRequest("Scores must contain one mark for every rubric criterion.")
    ids = [number(s, "rubric_id", 1, integer=True) for s in scores]
    if len(ids) != len(set(ids)) or set(ids) != {r.id for r in exam.rubrics}:
        raise BadRequest("Submit each rubric criterion exactly once.")
    evaluation = Evaluation(booking=booking, examiner_id=g.user.examiner.id, remarks=string(data, "remarks", 5000, False), total_marks=0)
    criteria = {r.id: r for r in exam.rubrics}
    total = 0
    awarded = []
    for score in scores:
        criterion = criteria[score["rubric_id"]]
        marks = number(score, "marks", 0, criterion.maximum_marks)
        awarded.append({"rubric_id": criterion.id, "criterion": criterion.name, "marks": marks,
                        "maximum_marks": criterion.maximum_marks, "weightage": criterion.weightage})
        total += marks / criterion.maximum_marks * criterion.weightage / 100 * exam.maximum_marks
    evaluation.total_marks = round(total, 2)
    evaluation.scores = awarded
    booking.status, booking.completed_at = "Completed", now()
    db.session.add(evaluation)
    db.session.commit()
    invalidate()
    return {"message": "Evaluation submitted.", "total_marks": evaluation.total_marks}, 201


@examiner.post("/slots/<int:ident>/complete")
@roles("Examiner")
def complete(ident):
    atomic()
    slot = owned_slot(ident)
    if slot.start > now() or slot.status in ("Cancelled", "Completed"):
        raise Conflict("Only started, active slots may be marked complete.")
    if any(b.status == "Booked" for b in slot.bookings):
        raise Conflict("Evaluate all booked students before completing this slot.")
    slot.status = "Completed"
    db.session.flush()
    remaining = db.session.scalar(db.select(func.count(Slot.id)).where(
        Slot.exam_id == slot.exam_id, Slot.status.not_in(["Completed", "Cancelled"])))
    if not remaining and now() >= slot.exam.booking_end:
        slot.exam.status = "Completed"
    db.session.commit()
    invalidate()
    return {"message": "Slot marked complete."}
