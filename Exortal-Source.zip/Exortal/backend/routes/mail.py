import hashlib
import smtplib
from email.message import EmailMessage
from pathlib import Path
from flask import current_app, render_template


def send_email(key, receiver, subject, template, **context):
    folder = Path(current_app.instance_path) / "outbox"
    folder.mkdir(exist_ok=True)
    filename = hashlib.sha256(key.encode()).hexdigest()
    message_path = folder / f"{filename}.eml"
    sent_path = folder / f"{filename}.sent"
    mode = current_app.config["MAIL_MODE"]
    if mode == "outbox" and message_path.exists():
        return "Local outbox"
    if mode == "smtp" and sent_path.exists():
        return "Sent"
    message = EmailMessage()
    message["From"] = current_app.config["SMTP_SENDER"]
    message["To"] = receiver
    message["Subject"] = subject
    message.set_content("This Exortal message contains an HTML examination update.")
    message.add_alternative(render_template(template, **context), subtype="html")
    try:
        if mode not in ("outbox", "smtp"):
            raise ValueError("MAIL_MODE must be outbox or smtp.")
        temporary = folder / f"{filename}.tmp"
        temporary.write_bytes(message.as_bytes())
        temporary.replace(message_path)
        if mode == "outbox":
            current_app.logger.info("Email saved locally (not externally sent): %s", subject)
            return "Local outbox"
        if not current_app.config["SMTP_HOST"]:
            raise ValueError("SMTP_HOST must be configured for SMTP delivery.")
        with smtplib.SMTP(current_app.config["SMTP_HOST"], current_app.config["SMTP_PORT"], timeout=20) as smtp:
            if current_app.config["SMTP_TLS"]:
                smtp.starttls()
            if current_app.config["SMTP_USERNAME"]:
                smtp.login(current_app.config["SMTP_USERNAME"], current_app.config["SMTP_PASSWORD"])
            smtp.send_message(message)
        sent_path.write_text("Sent", encoding="utf-8")
        return "Sent"
    except (OSError, smtplib.SMTPException, ValueError):
        current_app.logger.exception("Email delivery failed: %s", subject)
        raise
