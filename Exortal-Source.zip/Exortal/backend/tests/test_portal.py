import csv
import io
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from email import policy
from email.parser import BytesParser
from pathlib import Path
from uuid import uuid4
from unittest.mock import patch
from sqlalchemy import inspect
from werkzeug.exceptions import ServiceUnavailable
from werkzeug.security import check_password_hash, generate_password_hash
from app import create_app
from model import Booking, Course, Examination, Examiner, Slot, Student, User, db, now
from routes.extensions import iso
from routes.tasks import daily_reminders, export_examination_history, send_monthly_report


class PortalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.password = "  StrongTestPassword42!  "
        cls.hashed = generate_password_hash(cls.password)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(Path(self.temp.name) / "test.db")})
        self.app.instance_path = self.temp.name
        with self.app.app_context():
            initial_admin = db.session.scalar(db.select(User).where(User.role == "Admin"))
            self.default_admin_valid = initial_admin.email == "admin@exam.com" and check_password_hash(initial_admin.password, "admin123")
            self.initial_counts = {name: db.session.scalar(db.select(db.func.count()).select_from(table))
                                   for name, table in db.metadata.tables.items()}
            db.session.remove()
            db.drop_all()
            db.create_all()
            self.ids = {}
            self.profile_ids = {}
            for key, role in [("admin", "Admin"), ("examiner", "Examiner"), ("other", "Examiner"), ("student", "Student"), ("student2", "Student")]:
                user = User(email=f"{key}@example.test", password=self.hashed, role=role)
                if role == "Student":
                    user.student = Student(name=key, phone="9000000000", department="CS", roll_number=key)
                elif role == "Examiner":
                    user.examiner = Examiner(name=key, phone="9000000000", department="CS")
                db.session.add(user)
                db.session.flush()
                self.ids[key] = user.id
                if role != "Admin":
                    self.profile_ids[key] = (user.student if role == "Student" else user.examiner).id
            db.session.commit()
        self.clients = {}
        self.tokens = {}
        for key in self.ids:
            client = self.app.test_client()
            response = client.post("/api/login", json={"email": f"{key}@example.test", "password": self.password})
            self.assertEqual(response.status_code, 200, response.json)
            self.clients[key], self.tokens[key] = client, response.json["csrf"]

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.engine.dispose()
        self.temp.cleanup()

    def call(self, role, method, path, data=None):
        return self.clients[role].open("/api" + path, method=method, json=data, headers={"X-CSRF-TOKEN": self.tokens[role]})

    def prepare(self, capacity=1):
        course = self.call("admin", "POST", "/admin/courses", {"code": "CS101", "name": "Computer Science", "description": ""})
        self.assertEqual(course.status_code, 201, course.json)
        time = now()
        payload = {"course_id": course.json["id"], "name": "Practical examination", "exam_type": "Practical",
                   "duration": 30, "maximum_marks": 100, "instructions": "Bring your ID.",
                   "slot_creation_start": iso(time - timedelta(days=2)), "slot_creation_end": iso(time + timedelta(hours=1)),
                   "booking_start": iso(time + timedelta(hours=2)), "booking_end": iso(time + timedelta(hours=4)),
                   "examiner_ids": [self.profile_ids["examiner"], self.profile_ids["other"]]}
        response = self.call("admin", "POST", "/admin/examinations", payload)
        self.assertEqual(response.status_code, 201, response.json)
        exam_id = response.json["id"]
        self.assertEqual(self.call("admin", "PUT", f"/admin/examinations/{exam_id}/rubrics", {"criteria": [
            {"name": "Knowledge", "maximum_marks": 20, "weightage": 60, "description": ""},
            {"name": "Practice", "maximum_marks": 40, "weightage": 40, "description": ""},
        ]}).status_code, 200)
        self.assertEqual(self.call("admin", "POST", f"/admin/examinations/{exam_id}/status", {"status": "Slot Creation"}).status_code, 200)
        slot_payload = {"exam_id": exam_id, "start": iso(time + timedelta(hours=5)), "end": iso(time + timedelta(hours=5, minutes=30)),
                        "capacity": capacity, "location": "Lab", "meeting_link": ""}
        slot = self.call("examiner", "POST", "/examiner/slots", slot_payload)
        self.assertEqual(slot.status_code, 201, slot.json)
        self.exam_id, self.slot_id = exam_id, slot.json["id"]
        self.slot_payload = slot_payload
        return exam_id, slot.json["id"]

    def open_booking(self):
        with self.app.app_context():
            exam = db.session.get(Examination, self.exam_id)
            exam.slot_creation_end = now() - timedelta(hours=2)
            exam.booking_start = now() - timedelta(hours=1)
            db.session.commit()
        result = self.call("admin", "POST", f"/admin/examinations/{self.exam_id}/status", {"status": "Booking Open"})
        self.assertEqual(result.status_code, 200, result.json)

    def start_exam(self):
        with self.app.app_context():
            exam = db.session.get(Examination, self.exam_id)
            exam.slot_creation_end = now() - timedelta(hours=4)
            exam.booking_start = now() - timedelta(hours=3)
            exam.booking_end = now() - timedelta(hours=2)
            exam.status = "Closed"
            slot = db.session.get(Slot, self.slot_id)
            slot.start, slot.end = now() - timedelta(minutes=30), now()
            db.session.commit()

    def test_auth_roles_registration_csrf_and_logout(self):
        self.assertEqual(self.call("student", "GET", "/admin/users").status_code, 403)
        self.assertEqual(self.clients["admin"].post("/api/admin/courses", json={}).status_code, 401)
        response = self.app.test_client().post("/api/student/register", json={
            "email": "new@example.test", "password": "LongPassword42!", "name": "New Student", "department": "CS",
            "phone": "9000000000", "roll_number": "NEW", "role": "Admin"})
        self.assertEqual(response.status_code, 201)
        with self.app.app_context():
            registered = db.session.scalar(db.select(User).where(User.email == "new@example.test"))
            self.assertEqual(registered.role, "Student")
            self.assertEqual(registered.student.roll_number, "NEW")
            self.assertEqual(registered.student.user_id, registered.id)
            self.assertIsNone(registered.examiner)
            self.assertEqual(len(db.session.scalars(db.select(User).where(User.role == "Admin")).all()), 1)
        cookie = self.clients["student"].get_cookie("access_token_cookie", path="/api").value
        self.assertEqual(self.call("student", "POST", "/logout").status_code, 200)
        self.clients["student"].set_cookie("access_token_cookie", cookie, path="/api")
        self.assertEqual(self.call("student", "GET", "/session").status_code, 401)

    def test_timeline_duplicate_cancellation_and_rebooking(self):
        self.prepare()
        self.assertEqual(self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).status_code, 409)
        self.open_booking()
        created = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        self.assertEqual(created.status_code, 201, created.json)
        self.assertEqual(created.json["student_id"], self.profile_ids["student"])
        self.assertEqual(created.json["slot"]["examiner_id"], self.profile_ids["examiner"])
        blocked = self.call("admin", "PUT", f"/admin/users/{self.ids['student']}", {
            "name": "student", "department": "CS", "phone": "9000000000", "status": "Inactive"})
        self.assertEqual(blocked.status_code, 409)
        self.assertEqual(self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).status_code, 409)
        self.assertEqual(self.call("student2", "POST", "/student/bookings", {"slot_id": self.slot_id}).status_code, 409)
        self.assertEqual(self.call("student2", "POST", f"/student/bookings/{created.json['id']}/cancel").status_code, 403)
        self.assertEqual(self.call("student", "POST", f"/student/bookings/{created.json['id']}/cancel").status_code, 200)
        self.assertEqual(self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).status_code, 201)
        with self.app.app_context():
            self.assertEqual(db.session.get(Slot, self.slot_id).status, "Full")
            self.assertEqual(len(db.session.scalars(db.select(Booking)).all()), 2)

    def test_concurrent_last_seat_is_atomic(self):
        self.prepare()
        self.open_booking()
        barrier = threading.Barrier(2)

        def reserve(role):
            barrier.wait()
            return self.call(role, "POST", "/student/bookings", {"slot_id": self.slot_id}).status_code

        with ThreadPoolExecutor(max_workers=2) as executor:
            statuses = list(executor.map(reserve, ["student", "student2"]))
        self.assertEqual(sorted(statuses), [201, 409])

    def test_slot_rules_and_rubric_freeze(self):
        self.prepare()
        self.assertEqual(self.call("examiner", "POST", "/examiner/slots", self.slot_payload).status_code, 409)
        self.assertEqual(self.call("other", "PUT", f"/examiner/slots/{self.slot_id}", self.slot_payload).status_code, 403)
        invalid = {**self.slot_payload, "capacity": 0}
        self.assertEqual(self.call("examiner", "PUT", f"/examiner/slots/{self.slot_id}", invalid).status_code, 400)
        self.open_booking()
        self.assertEqual(self.call("examiner", "DELETE", f"/examiner/slots/{self.slot_id}").status_code, 409)
        self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        self.assertEqual(self.call("admin", "PUT", f"/admin/examinations/{self.exam_id}/rubrics", {"criteria": []}).status_code, 409)
        self.assertEqual(self.call("admin", "POST", f"/admin/examinations/{self.exam_id}/status", {"status": "Completed"}).status_code, 409)

    def test_evaluation_publication_and_export_privacy(self):
        self.prepare()
        self.open_booking()
        booking = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).json
        rubrics = self.call("examiner", "GET", f"/examinations/{self.exam_id}/rubrics").json["items"]
        payload = {"scores": [{"rubric_id": rubrics[0]["id"], "marks": 10}, {"rubric_id": rubrics[1]["id"], "marks": 40}], "remarks": "Good practical work."}
        path = f"/examiner/bookings/{booking['id']}/evaluate"
        self.assertEqual(self.call("examiner", "POST", path, payload).status_code, 409)
        self.start_exam()
        self.assertEqual(self.call("student", "POST", f"/student/bookings/{booking['id']}/cancel").status_code, 409)
        self.assertEqual(self.call("other", "POST", path, payload).status_code, 403)
        self.assertEqual(self.call("examiner", "POST", path, {**payload, "scores": [{"rubric_id": rubrics[0]["id"], "marks": -1}, payload["scores"][1]]}).status_code, 400)
        response = self.call("examiner", "POST", path, payload)
        self.assertEqual(response.status_code, 201, response.json)
        self.assertEqual(response.json["total_marks"], 70)
        self.assertIsNone(self.call("student", "GET", "/student/bookings").json["items"][0]["evaluation"])
        job_id = str(uuid4())
        with self.app.app_context():
            profile = db.session.get(Student, self.profile_ids["student"])
            profile.export_task_id, profile.export_status = job_id, "Queued"
            db.session.commit()
            export_examination_history.run(profile.id, job_id)
        exported = self.call("student", "GET", f"/student/exports/{job_id}/download")
        rows = list(csv.reader(io.StringIO(exported.data.decode("utf-8-sig"))))
        exported.close()
        self.assertEqual(rows[1][5], "")
        self.assertEqual(self.call("student2", "GET", f"/student/exports/{job_id}/download").status_code, 403)
        self.assertEqual(self.call("examiner", "POST", f"/examiner/slots/{self.slot_id}/complete").status_code, 200)
        self.assertEqual(self.call("admin", "POST", f"/admin/examinations/{self.exam_id}/publish").status_code, 200)
        result = self.call("student", "GET", "/student/bookings").json["items"][0]["evaluation"]
        self.assertEqual(result["total_marks"], 70)
        self.assertEqual(result["remarks"], "Good practical work.")
        self.assertEqual(self.call("examiner", "POST", path, payload).status_code, 409)

    def test_admin_reschedule_and_reassign_keeps_history(self):
        self.prepare(capacity=2)
        second = self.call("other", "POST", "/examiner/slots", {**self.slot_payload, "capacity": 1})
        self.assertEqual(second.status_code, 201, second.json)
        self.open_booking()
        booking = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).json
        self.assertEqual(self.call("admin", "POST", f"/admin/bookings/{booking['id']}/reschedule",
                                   {"slot_id": second.json["id"], "reason": "Examiner unavailable"}).status_code, 200)
        history = self.call("student", "GET", "/student/bookings").json["items"][0]["reschedule_history"]
        self.assertEqual(history[0]["previous_slot_id"], self.slot_id)
        self.assertEqual(history[0]["reason"], "Examiner unavailable")
        with self.app.app_context():
            self.assertEqual(db.session.get(Booking, booking["id"]).slot_id, second.json["id"])
            self.assertEqual(db.session.get(Slot, second.json["id"]).status, "Full")
        new_start = now() + timedelta(days=2)
        changed = self.call("admin", "PUT", f"/admin/slots/{second.json['id']}", {
            "start": iso(new_start), "end": iso(new_start + timedelta(minutes=30)), "capacity": 1,
            "examiner_id": self.profile_ids["examiner"], "reason": "Faculty reassignment", "location": "Lab B", "meeting_link": ""})
        self.assertEqual(changed.status_code, 200, changed.json)
        self.assertEqual(self.call("other", "GET", "/examiner/bookings").json["items"], [])

    def test_monthly_report_runs_with_local_mail_and_is_idempotent(self):
        with self.app.app_context():
            first = send_monthly_report.run()
            second = send_monthly_report.run()
            self.assertEqual(first["status"], "Local outbox")
            self.assertEqual(second["status"], "Local outbox")
            self.assertEqual(len(list((Path(self.temp.name) / "outbox").glob("*.eml"))), 1)

    def test_reminder_contains_examination_schedule_and_instructions(self):
        self.prepare()
        self.open_booking()
        self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        with self.app.app_context():
            slot = db.session.get(Slot, self.slot_id)
            slot.start, slot.end = now() + timedelta(hours=1), now() + timedelta(hours=1, minutes=30)
            slot.exam.booking_end = now() + timedelta(minutes=30)
            db.session.commit()
            result = daily_reminders.run()
            self.assertEqual(result["reminders"], 1)
            mail_path = next((Path(self.temp.name) / "outbox").glob("*.eml"))
            mail = BytesParser(policy=policy.default).parsebytes(mail_path.read_bytes())
            self.assertEqual(mail["To"], "student@example.test")
            html = mail.get_body(preferencelist=("html",)).get_content()
            self.assertIn("Practical examination", html)
            self.assertIn("Bring your ID.", html)
            self.assertIn("examiner", html)
            self.assertIn("Date and time", html)

    def test_deactivated_account_loses_existing_session(self):
        response = self.call("admin", "PUT", f"/admin/users/{self.ids['student']}", {
            "name": "student", "department": "CS", "phone": "9000000000", "status": "Inactive"})
        self.assertEqual(response.status_code, 200, response.json)
        self.assertEqual(self.call("student", "GET", "/student/dashboard").status_code, 401)

    def test_core_schema_and_admin_only_initialization(self):
        self.assertTrue(self.default_admin_valid)
        expected = {"user", "student", "examiner", "course", "examination", "booking", "slot", "evaluation",
                    "rubric", "examiner_assignments"}
        with self.app.app_context():
            self.assertEqual(set(inspect(db.engine).get_table_names()), expected)
            self.assertNotIn("name", {column["name"] for column in inspect(db.engine).get_columns("user")})
            self.assertEqual(self.initial_counts, {name: 1 if name == "user" else 0 for name in expected})
            self.assertEqual(inspect(db.engine).get_foreign_keys("booking")[0]["referred_table"], "student")
            self.assertEqual(inspect(db.engine).get_foreign_keys("student")[0]["referred_table"], "user")
        self.assertEqual(self.call("student", "GET", "/notifications").status_code, 404)
        self.assertEqual(self.call("admin", "GET", "/admin/history").status_code, 404)
        self.assertEqual(self.call("admin", "GET", "/admin/mail/1").status_code, 404)

    def test_admin_creates_examiner_profile_and_student_edits_own_profile(self):
        result = self.call("admin", "POST", "/admin/users", {
            "name": "New Examiner", "email": "faculty@example.test", "department": "Physics",
            "phone": "9000000001", "password": "123"})
        self.assertEqual(result.status_code, 201, result.json)
        login = self.app.test_client().post("/api/login", json={"email": "faculty@example.test", "password": "123"})
        self.assertEqual(login.status_code, 200)
        with self.app.app_context():
            account = db.session.get(User, result.json["id"])
            self.assertEqual(account.examiner.id, result.json["examiner_id"])
            self.assertIsNone(account.student)
            self.assertNotEqual(account.id, account.examiner.id)
        result = self.call("student", "PUT", "/profile", {"name": "Updated Student", "department": "CS", "phone": "9999999999"})
        self.assertEqual(result.status_code, 200, result.json)
        with self.app.app_context():
            self.assertEqual(db.session.get(Student, self.profile_ids["student"]).name, "Updated Student")
        users = self.call("admin", "GET", "/admin/users?role=Student&q=Updated").json["items"]
        self.assertEqual(len(users), 1)
        self.assertEqual(users[0]["student_id"], self.profile_ids["student"])

    def test_passwords_have_no_length_or_complexity_rule(self):
        for index, password in enumerate(("123", "a", "x" * 200)):
            with self.subTest(password_length=len(password)):
                client = self.app.test_client()
                address = f"simple{index}@example.test"
                registered = client.post("/api/student/register", json={
                    "name": "Student", "email": address, "password": password, "roll_number": f"SIMPLE{index}",
                    "department": "CS", "phone": "9000000000"})
                self.assertEqual(registered.status_code, 201, registered.json)
                self.assertEqual(client.post("/api/login", json={"email": address, "password": password}).status_code, 200)
                self.assertEqual(client.post("/api/login", json={"email": address, "password": ""}).status_code, 400)

    def test_manual_frontend_origin_and_csrf_preflight(self):
        client = self.app.test_client()
        origin = "http://localhost:5173"
        preflight = client.options("/api/login", headers={
            "Origin": origin, "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type,x-csrf-token"})
        self.assertEqual(preflight.status_code, 200)
        self.assertEqual(preflight.headers["Access-Control-Allow-Origin"], origin)
        self.assertEqual(preflight.headers["Access-Control-Allow-Credentials"], "true")
        self.assertIn("x-csrf-token", preflight.headers["Access-Control-Allow-Headers"].lower())
        response = client.post("/api/login", json={"email": "student@example.test", "password": self.password},
                               headers={"Origin": origin})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["Access-Control-Allow-Origin"], origin)
        updated = client.put("/api/profile", json={"name": "Student", "department": "CS", "phone": "9000000000"},
                             headers={"Origin": origin, "X-CSRF-TOKEN": response.json["csrf"]})
        self.assertEqual(updated.status_code, 200)
        rejected = client.post("/api/login", json={}, headers={"Origin": "http://untrusted.example"})
        self.assertEqual(rejected.status_code, 403)
        self.assertNotIn("Access-Control-Allow-Origin", rejected.headers)

    def test_download_click_resumes_pending_export_without_duplicate_job(self):
        with patch("routes.tasks.queue_task", return_value="task") as queue:
            first = self.call("student", "POST", "/student/exports")
            resumed = self.call("student", "POST", "/student/exports")
            self.assertEqual(first.status_code, 202)
            self.assertEqual(first.json["id"], resumed.json["id"])
            queue.assert_called_once()
        with self.app.app_context():
            export_examination_history.run(self.profile_ids["student"], first.json["id"])
        result = self.call("student", "GET", f"/student/exports/{first.json['id']}/download")
        self.assertEqual(result.status_code, 200)
        self.assertIn("attachment", result.headers["Content-Disposition"])
        result.close()

    def test_export_queue_failure_is_visible_and_retryable(self):
        with patch("routes.tasks.queue_task", side_effect=ServiceUnavailable("Broker unavailable")):
            failed = self.call("student", "POST", "/student/exports")
        self.assertEqual(failed.status_code, 503)
        self.assertEqual(self.call("student", "GET", "/student/exports").json["items"][0]["status"], "Failed")
        with patch("routes.tasks.queue_task", return_value="task"):
            self.assertEqual(self.call("student", "POST", "/student/exports").status_code, 202)


if __name__ == "__main__":
    unittest.main()
