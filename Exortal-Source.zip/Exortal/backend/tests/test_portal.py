import csv
import io
import runpy
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from email import policy
from email.parser import BytesParser
from pathlib import Path
from uuid import uuid4
from unittest.mock import Mock, patch
from sqlalchemy import inspect
from flask import Flask
from kombu.exceptions import OperationalError
from werkzeug.security import check_password_hash, generate_password_hash
from model import Booking, Course, Examination, Examiner, Slot, Student, User, db
from routes.tasks import daily_reminders, export_examination_history, send_monthly_report


def iso(value):
    return value.strftime("%Y-%m-%dT%H:%M:%SZ")


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class PortalTests(unittest.TestCase):
    password = "  StrongTestPassword42!  "
    hashed = generate_password_hash(password)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        backend = Path(__file__).resolve().parents[1]
        with patch(
            "flask.Flask",
            side_effect=lambda name: Flask(
                name, instance_path=self.temp.name, root_path=str(backend)
            ),
        ):
            self.app = runpy.run_path(str(backend / "app.py"))["app"]
        self.app.config["TESTING"] = True
        self.task_app_patch = patch("routes.tasks.app", self.app)
        self.task_app_patch.start()
        self.addCleanup(self.task_app_patch.stop)
        self.cache = Mock()
        self.cache.get.return_value = None
        for module in ("auth", "admin", "examiner", "student"):
            cache_patch = patch(f"routes.{module}.redis_client", self.cache)
            cache_patch.start()
            self.addCleanup(cache_patch.stop)
        for variable, value in (("SENDER", "sender@example.test"), ("PASSWORD", "test-only")):
            mail_patch = patch(f"routes.mail.{variable}", value)
            mail_patch.start()
            self.addCleanup(mail_patch.stop)
        smtp_patch = patch("routes.mail.smtplib.SMTP")
        self.smtp = smtp_patch.start().return_value.__enter__.return_value
        self.addCleanup(smtp_patch.stop)
        result_patch = patch("routes.student.celery.AsyncResult")
        self.task_result = result_patch.start().return_value
        self.task_result.state = "SUCCESS"
        self.task_result.successful.return_value = True
        self.addCleanup(result_patch.stop)
        with self.app.app_context():
            initial_admin = db.session.scalar(db.select(User).where(User.role == "Admin"))
            self.default_admin_valid = (
                initial_admin.email == "admin@exam.com"
                and check_password_hash(initial_admin.password, "admin123")
            )
            self.initial_counts = {
                name: db.session.scalar(db.select(db.func.count()).select_from(table))
                for name, table in db.metadata.tables.items()
            }
            db.session.remove()
            db.drop_all()
            db.create_all()
            self.ids = {}
            self.profile_ids = {}
            for key, role in [
                ("admin", "Admin"),
                ("examiner", "Examiner"),
                ("other", "Examiner"),
                ("student", "Student"),
                ("student2", "Student"),
            ]:
                user = User(email=f"{key}@example.test", password=self.hashed, role=role)
                if role == "Student":
                    user.student = Student(
                        name=key, phone="9000000000", department="CS", roll_number=key
                    )
                elif role == "Examiner":
                    user.examiner = Examiner(name=key, phone="9000000000", department="CS")
                db.session.add(user)
                db.session.flush()
                self.ids[key] = user.id
                if role != "Admin":
                    self.profile_ids[key] = (
                        user.student if role == "Student" else user.examiner
                    ).id
            db.session.commit()
        self.clients = {}
        for key in self.ids:
            client = self.app.test_client()
            response = client.post(
                "/api/login", json={"email": f"{key}@example.test", "password": self.password}
            )
            self.assertEqual(response.status_code, 200, response.json)
            self.clients[key] = client
            self.assertEqual(set(response.json), {"user"})

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.engine.dispose()
        self.temp.cleanup()

    def call(self, role, method, path, data=None):
        return self.clients[role].open("/api" + path, method=method, json=data)

    def prepare(self, capacity=1):
        course = self.call(
            "admin",
            "POST",
            "/admin/courses",
            {"code": "CS101", "name": "Computer Science", "description": ""},
        )
        self.assertEqual(course.status_code, 201, course.json)
        time = now()
        payload = {
            "course_id": course.json["id"],
            "name": "Practical examination",
            "exam_type": "Practical",
            "duration": 30,
            "maximum_marks": 100,
            "instructions": "Bring your ID.",
            "slot_creation_start": iso(time - timedelta(days=2)),
            "slot_creation_end": iso(time + timedelta(hours=1)),
            "booking_start": iso(time + timedelta(hours=2)),
            "booking_end": iso(time + timedelta(hours=4)),
            "examiner_ids": [self.profile_ids["examiner"], self.profile_ids["other"]],
        }
        response = self.call("admin", "POST", "/admin/examinations", payload)
        self.assertEqual(response.status_code, 201, response.json)
        exam_id = response.json["id"]
        self.assertEqual(
            self.call(
                "admin",
                "PUT",
                f"/admin/examinations/{exam_id}/rubrics",
                {
                    "criteria": [
                        {
                            "name": "Knowledge",
                            "maximum_marks": 20,
                            "weightage": 60,
                            "description": "",
                        },
                        {
                            "name": "Practice",
                            "maximum_marks": 40,
                            "weightage": 40,
                            "description": "",
                        },
                    ]
                },
            ).status_code,
            200,
        )
        self.assertEqual(
            self.call(
                "admin",
                "POST",
                f"/admin/examinations/{exam_id}/status",
                {"status": "Slot Creation"},
            ).status_code,
            200,
        )
        slot_payload = {
            "exam_id": exam_id,
            "start": iso(time + timedelta(hours=5)),
            "end": iso(time + timedelta(hours=5, minutes=30)),
            "capacity": capacity,
            "location": "Lab",
            "meeting_link": "",
        }
        slot = self.call("examiner", "POST", "/examiner/slots", slot_payload)
        self.assertEqual(slot.status_code, 201, slot.json)
        self.exam_id, self.slot_id = exam_id, slot.json["id"]
        self.slot_payload = slot_payload
        return exam_id, slot.json["id"]

    def open_booking(self):
        with self.app.app_context():
            exam = db.session.get(Examination, self.exam_id)
            exam.slot_creation_end = now() - timedelta(hours=2)
            exam.booking_start = now() - timedelta(hours=1)
            db.session.commit()
        result = self.call(
            "admin",
            "POST",
            f"/admin/examinations/{self.exam_id}/status",
            {"status": "Booking Open"},
        )
        self.assertEqual(result.status_code, 200, result.json)

    def start_exam(self):
        with self.app.app_context():
            exam = db.session.get(Examination, self.exam_id)
            exam.slot_creation_end = now() - timedelta(hours=4)
            exam.booking_start = now() - timedelta(hours=3)
            exam.booking_end = now() - timedelta(hours=2)
            exam.status = "Closed"
            slot = db.session.get(Slot, self.slot_id)
            slot.start, slot.end = now() - timedelta(minutes=30), now()
            db.session.commit()

    def test_session_login_roles_registration_and_logout(self):
        self.assertEqual(self.call("student", "GET", "/admin/users").status_code, 403)
        self.assertEqual(
            self.app.test_client().post("/api/admin/courses", json={}).status_code, 401
        )
        with self.clients["student"].session_transaction() as state:
            self.assertEqual(state["user_id"], self.ids["student"])
            self.assertEqual(state["role"], "Student")
        response = self.app.test_client().post(
            "/api/student/register",
            json={
                "email": "new@example.test",
                "password": "LongPassword42!",
                "name": "New Student",
                "department": "CS",
                "phone": "9000000000",
                "roll_number": "NEW",
                "role": "Admin",
            },
        )
        self.assertEqual(response.status_code, 201)
        with self.app.app_context():
            registered = db.session.scalar(db.select(User).where(User.email == "new@example.test"))
            self.assertEqual(registered.role, "Student")
            self.assertEqual(registered.student.roll_number, "NEW")
            self.assertEqual(registered.student.user_id, registered.id)
            self.assertIsNone(registered.examiner)
            self.assertEqual(
                len(db.session.scalars(db.select(User).where(User.role == "Admin")).all()), 1
            )
        self.assertIsNotNone(self.clients["student"].get_cookie("session"))
        self.assertEqual(self.call("student", "POST", "/logout").status_code, 200)
        self.assertIsNone(self.clients["student"].get_cookie("session"))
        self.assertEqual(self.call("student", "GET", "/session").status_code, 401)

    def test_timeline_duplicate_cancellation_and_rebooking(self):
        self.prepare()
        self.assertEqual(
            self.call(
                "student", "POST", "/student/bookings", {"slot_id": self.slot_id}
            ).status_code,
            409,
        )
        self.open_booking()
        created = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        self.assertEqual(created.status_code, 201, created.json)
        self.assertEqual(created.json["student_id"], self.profile_ids["student"])
        self.assertEqual(created.json["slot"]["examiner_id"], self.profile_ids["examiner"])
        blocked = self.call(
            "admin",
            "PUT",
            f"/admin/users/{self.ids['student']}",
            {"name": "student", "department": "CS", "phone": "9000000000", "status": "Inactive"},
        )
        self.assertEqual(blocked.status_code, 409)
        self.assertEqual(
            self.call(
                "student", "POST", "/student/bookings", {"slot_id": self.slot_id}
            ).status_code,
            409,
        )
        self.assertEqual(
            self.call(
                "student2", "POST", "/student/bookings", {"slot_id": self.slot_id}
            ).status_code,
            409,
        )
        self.assertEqual(
            self.call(
                "student2", "POST", f"/student/bookings/{created.json['id']}/cancel"
            ).status_code,
            403,
        )
        self.assertEqual(
            self.call(
                "student", "POST", f"/student/bookings/{created.json['id']}/cancel"
            ).status_code,
            200,
        )
        self.assertEqual(
            self.call(
                "student", "POST", "/student/bookings", {"slot_id": self.slot_id}
            ).status_code,
            201,
        )
        with self.app.app_context():
            self.assertEqual(db.session.get(Slot, self.slot_id).status, "Full")
            self.assertEqual(len(db.session.scalars(db.select(Booking)).all()), 2)

    def test_concurrent_last_seat_is_atomic(self):
        self.prepare()
        self.open_booking()
        barrier = threading.Barrier(2)

        def reserve(role):
            barrier.wait()
            return self.call(
                role, "POST", "/student/bookings", {"slot_id": self.slot_id}
            ).status_code

        with ThreadPoolExecutor(max_workers=2) as executor:
            statuses = list(executor.map(reserve, ["student", "student2"]))
        self.assertEqual(sorted(statuses), [201, 409])

    def test_slot_rules_and_rubric_freeze(self):
        self.prepare()
        self.assertEqual(
            self.call("examiner", "POST", "/examiner/slots", self.slot_payload).status_code, 409
        )
        self.assertEqual(
            self.call(
                "other", "PUT", f"/examiner/slots/{self.slot_id}", self.slot_payload
            ).status_code,
            403,
        )
        invalid = {**self.slot_payload, "capacity": 0}
        self.assertEqual(
            self.call("examiner", "PUT", f"/examiner/slots/{self.slot_id}", invalid).status_code,
            400,
        )
        self.open_booking()
        self.assertEqual(
            self.call("examiner", "DELETE", f"/examiner/slots/{self.slot_id}").status_code, 409
        )
        self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        self.assertEqual(
            self.call(
                "admin", "PUT", f"/admin/examinations/{self.exam_id}/rubrics", {"criteria": []}
            ).status_code,
            409,
        )
        self.assertEqual(
            self.call(
                "admin",
                "POST",
                f"/admin/examinations/{self.exam_id}/status",
                {"status": "Completed"},
            ).status_code,
            409,
        )

    def test_evaluation_publication_and_export_privacy(self):
        self.prepare()
        self.open_booking()
        booking = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).json
        rubrics = self.call("examiner", "GET", f"/examinations/{self.exam_id}/rubrics").json[
            "items"
        ]
        payload = {
            "scores": [
                {"rubric_id": rubrics[0]["id"], "marks": 10},
                {"rubric_id": rubrics[1]["id"], "marks": 40},
            ],
            "remarks": "Good practical work.",
        }
        path = f"/examiner/bookings/{booking['id']}/evaluate"
        self.assertEqual(self.call("examiner", "POST", path, payload).status_code, 409)
        self.start_exam()
        self.assertEqual(
            self.call("student", "POST", f"/student/bookings/{booking['id']}/cancel").status_code,
            409,
        )
        self.assertEqual(self.call("other", "POST", path, payload).status_code, 403)
        self.assertEqual(
            self.call(
                "examiner",
                "POST",
                path,
                {
                    **payload,
                    "scores": [{"rubric_id": rubrics[0]["id"], "marks": -1}, payload["scores"][1]],
                },
            ).status_code,
            400,
        )
        response = self.call("examiner", "POST", path, payload)
        self.assertEqual(response.status_code, 201, response.json)
        self.assertEqual(response.json["total_marks"], 70)
        self.assertIsNone(
            self.call("student", "GET", "/student/bookings").json["items"][0]["evaluation"]
        )
        job_id = str(uuid4())
        with self.app.app_context():
            profile = db.session.get(Student, self.profile_ids["student"])
            profile.export_task_id = job_id
            db.session.commit()
            export_examination_history.apply(args=[profile.id], task_id=job_id).get()
        exported = self.call("student", "GET", f"/student/exports/{job_id}/download")
        rows = list(csv.reader(io.StringIO(exported.data.decode("utf-8-sig"))))
        exported.close()
        self.assertEqual(rows[1][5], "")
        self.assertEqual(
            self.call("student2", "GET", f"/student/exports/{job_id}/download").status_code, 403
        )
        self.assertEqual(
            self.call("examiner", "POST", f"/examiner/slots/{self.slot_id}/complete").status_code,
            200,
        )
        self.assertEqual(
            self.call("admin", "POST", f"/admin/examinations/{self.exam_id}/publish").status_code,
            200,
        )
        result = self.call("student", "GET", "/student/bookings").json["items"][0]["evaluation"]
        self.assertEqual(result["total_marks"], 70)
        self.assertEqual(result["remarks"], "Good practical work.")
        self.assertEqual(self.call("examiner", "POST", path, payload).status_code, 409)

    def test_admin_reschedule_and_reassign_keeps_history(self):
        self.prepare(capacity=2)
        second = self.call("other", "POST", "/examiner/slots", {**self.slot_payload, "capacity": 1})
        self.assertEqual(second.status_code, 201, second.json)
        self.open_booking()
        booking = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id}).json
        self.assertEqual(
            self.call(
                "admin",
                "POST",
                f"/admin/bookings/{booking['id']}/reschedule",
                {"slot_id": second.json["id"], "reason": "Examiner unavailable"},
            ).status_code,
            200,
        )
        history = self.call("student", "GET", "/student/bookings").json["items"][0][
            "reschedule_history"
        ]
        self.assertEqual(history[0]["previous_slot_id"], self.slot_id)
        self.assertEqual(history[0]["reason"], "Examiner unavailable")
        with self.app.app_context():
            self.assertEqual(db.session.get(Booking, booking["id"]).slot_id, second.json["id"])
            self.assertEqual(db.session.get(Slot, second.json["id"]).status, "Full")
        new_start = now() + timedelta(days=2)
        changed = self.call(
            "admin",
            "PUT",
            f"/admin/slots/{second.json['id']}",
            {
                "start": iso(new_start),
                "end": iso(new_start + timedelta(minutes=30)),
                "capacity": 1,
                "examiner_id": self.profile_ids["examiner"],
                "reason": "Faculty reassignment",
                "location": "Lab B",
                "meeting_link": "",
            },
        )
        self.assertEqual(changed.status_code, 200, changed.json)
        self.assertEqual(self.call("other", "GET", "/examiner/bookings").json["items"], [])

    def test_monthly_report_sends_html_to_admin(self):
        with self.app.app_context():
            result = send_monthly_report.run()
        self.assertEqual(result, "Monthly Report Sent")
        sender, receiver, message = self.smtp.sendmail.call_args.args
        self.assertEqual(sender, "sender@example.test")
        self.assertEqual(receiver, "admin@example.test")
        mail = BytesParser(policy=policy.default).parsebytes(message.encode())
        self.assertEqual(mail.get_content_type(), "text/html")
        self.assertIn("Exortal", mail.get_content())
        self.smtp.starttls.assert_called_once()
        self.smtp.login.assert_called_once_with("sender@example.test", "test-only")

    def test_reminder_contains_examination_schedule_and_instructions(self):
        self.prepare()
        self.open_booking()
        self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        with self.app.app_context():
            slot = db.session.get(Slot, self.slot_id)
            slot.start, slot.end = now() + timedelta(hours=1), now() + timedelta(
                hours=1, minutes=30
            )
            slot.exam.booking_end = now() + timedelta(minutes=30)
            db.session.commit()
            result = daily_reminders.run()
            self.assertEqual(result, "Reminder Emails Sent")
            self.smtp.sendmail.assert_called_once()
            mail = BytesParser(policy=policy.default).parsebytes(
                self.smtp.sendmail.call_args.args[2].encode()
            )
            self.assertEqual(mail["To"], "student@example.test")
            html = mail.get_body(preferencelist=("html",)).get_content()
            self.assertIn("Practical examination", html)
            self.assertIn("Bring your ID.", html)
            self.assertIn("examiner", html)
            self.assertIn("Date and time", html)

    def test_deactivated_account_loses_existing_session(self):
        response = self.call(
            "admin",
            "PUT",
            f"/admin/users/{self.ids['student']}",
            {"name": "student", "department": "CS", "phone": "9000000000", "status": "Inactive"},
        )
        self.assertEqual(response.status_code, 200, response.json)
        self.assertEqual(self.call("student", "GET", "/student/dashboard").status_code, 401)

    def test_core_schema_and_admin_only_initialization(self):
        self.assertTrue(self.default_admin_valid)
        expected = {
            "user",
            "student",
            "examiner",
            "course",
            "examination",
            "booking",
            "slot",
            "evaluation",
            "rubric",
            "examiner_assignments",
        }
        with self.app.app_context():
            self.assertEqual(set(inspect(db.engine).get_table_names()), expected)
            self.assertNotIn(
                "name", {column["name"] for column in inspect(db.engine).get_columns("user")}
            )
            self.assertEqual(
                self.initial_counts, {name: 1 if name == "user" else 0 for name in expected}
            )
            self.assertEqual(
                inspect(db.engine).get_foreign_keys("booking")[0]["referred_table"], "student"
            )
            self.assertEqual(
                inspect(db.engine).get_foreign_keys("student")[0]["referred_table"], "user"
            )
        self.assertEqual(self.call("student", "GET", "/notifications").status_code, 404)
        self.assertEqual(self.call("admin", "GET", "/admin/history").status_code, 404)
        self.assertEqual(self.call("admin", "GET", "/admin/mail/1").status_code, 404)

    def test_admin_creates_examiner_profile_and_student_edits_own_profile(self):
        result = self.call(
            "admin",
            "POST",
            "/admin/users",
            {
                "name": "New Examiner",
                "email": "faculty@example.test",
                "department": "Physics",
                "phone": "9000000001",
                "password": "123",
            },
        )
        self.assertEqual(result.status_code, 201, result.json)
        login = self.app.test_client().post(
            "/api/login", json={"email": "faculty@example.test", "password": "123"}
        )
        self.assertEqual(login.status_code, 200)
        with self.app.app_context():
            account = db.session.get(User, result.json["id"])
            self.assertEqual(account.examiner.id, result.json["examiner_id"])
            self.assertIsNone(account.student)
            self.assertNotEqual(account.id, account.examiner.id)
        result = self.call(
            "student",
            "PUT",
            "/profile",
            {"name": "Updated Student", "department": "CS", "phone": "9999999999"},
        )
        self.assertEqual(result.status_code, 200, result.json)
        with self.app.app_context():
            self.assertEqual(
                db.session.get(Student, self.profile_ids["student"]).name, "Updated Student"
            )
        users = self.call("admin", "GET", "/admin/users?role=Student&q=Updated").json["items"]
        self.assertEqual(len(users), 1)
        self.assertEqual(users[0]["student_id"], self.profile_ids["student"])

    def test_passwords_have_no_length_or_complexity_rule(self):
        for index, password in enumerate(("123", "a", "x" * 200)):
            with self.subTest(password_length=len(password)):
                client = self.app.test_client()
                address = f"simple{index}@example.test"
                registered = client.post(
                    "/api/student/register",
                    json={
                        "name": "Student",
                        "email": address,
                        "password": password,
                        "roll_number": f"SIMPLE{index}",
                        "department": "CS",
                        "phone": "9000000000",
                    },
                )
                self.assertEqual(registered.status_code, 201, registered.json)
                self.assertEqual(
                    client.post(
                        "/api/login", json={"email": address, "password": password}
                    ).status_code,
                    200,
                )
                self.assertEqual(
                    client.post("/api/login", json={"email": address, "password": ""}).status_code,
                    400,
                )

    def test_manual_frontend_origin_and_session_cookie(self):
        client = self.app.test_client()
        origin = "http://localhost:5173"
        preflight = client.options(
            "/api/login",
            headers={
                "Origin": origin,
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "content-type",
            },
        )
        self.assertEqual(preflight.status_code, 200)
        self.assertEqual(preflight.headers["Access-Control-Allow-Origin"], origin)
        self.assertEqual(preflight.headers["Access-Control-Allow-Credentials"], "true")
        self.assertIn("content-type", preflight.headers["Access-Control-Allow-Headers"].lower())
        response = client.post(
            "/api/login",
            json={"email": "student@example.test", "password": self.password},
            headers={"Origin": origin},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["Access-Control-Allow-Origin"], origin)
        updated = client.put(
            "/api/profile",
            json={"name": "Student", "department": "CS", "phone": "9000000000"},
            headers={"Origin": origin},
        )
        self.assertEqual(updated.status_code, 200)
        rejected = client.post(
            "/api/login", json={}, headers={"Origin": "http://untrusted.example"}
        )
        self.assertEqual(rejected.status_code, 400)
        self.assertNotIn("Access-Control-Allow-Origin", rejected.headers)
        self.assertEqual(client.post("/api/login", data={"email": "test"}).status_code, 415)

    def test_download_uses_owned_celery_job_and_allows_new_export(self):
        with patch("routes.student.export_examination_history.delay") as queue:
            queue.side_effect = [Mock(id="first-job"), Mock(id="second-job")]
            first = self.call("student", "POST", "/student/exports")
            self.assertEqual(first.status_code, 202)
            self.task_result.state = "PENDING"
            self.assertEqual(
                self.call("student", "GET", "/student/exports").json["items"][0]["status"],
                "Queued",
            )
            renewed = self.call("student", "POST", "/student/exports")
            self.assertEqual(renewed.json["id"], "second-job")
            self.assertEqual(queue.call_count, 2)
        with self.app.app_context():
            export_examination_history.apply(
                args=[self.profile_ids["student"]], task_id="second-job"
            ).get()
        self.assertEqual(
            self.call("student", "GET", "/student/exports/first-job/download").status_code, 403
        )
        self.task_result.state = "SUCCESS"
        result = self.call("student", "GET", "/student/exports/second-job/download")
        self.assertEqual(result.status_code, 200)
        self.assertIn("attachment", result.headers["Content-Disposition"])
        result.close()

    def test_export_queue_failure_is_visible_and_retryable(self):
        with patch(
            "routes.student.export_examination_history.delay",
            side_effect=OperationalError("Broker unavailable"),
        ):
            with self.assertLogs(self.app.logger, level="ERROR"):
                failed = self.call("student", "POST", "/student/exports")
        self.assertEqual(failed.status_code, 503)
        self.assertEqual(self.call("student", "GET", "/student/exports").json["items"], [])
        with patch(
            "routes.student.export_examination_history.delay", return_value=Mock(id="retry")
        ):
            self.assertEqual(self.call("student", "POST", "/student/exports").status_code, 202)
        self.task_result.state = "FAILURE"
        failed = self.call("student", "GET", "/student/exports").json["items"][0]
        self.assertEqual(failed["status"], "Failed")
        self.assertIn("failed", failed["error"])

    def test_rubric_cache_expires_and_is_cleared_after_changes(self):
        self.prepare()
        self.app.config["TESTING"] = False
        cache = Mock()
        with patch("routes.student.redis_client", cache), patch("routes.admin.redis_client", cache):
            cache.get.return_value = None
            path = f"/examinations/{self.exam_id}/rubrics"
            first = self.call("examiner", "GET", path)
            self.assertEqual(first.status_code, 200)
            key, expiry, saved = cache.setex.call_args.args
            self.assertEqual(key, f"examination_rubrics_{self.exam_id}")
            self.assertEqual(expiry, 120)
            cache.get.return_value = saved
            self.assertEqual(self.call("examiner", "GET", path).json, first.json)
            cache.setex.assert_called_once()
            changed = self.call(
                "admin",
                "PUT",
                f"/admin/examinations/{self.exam_id}/rubrics",
                {
                    "criteria": [
                        {"name": "Updated criterion", "maximum_marks": 100, "weightage": 100}
                    ]
                },
            )
            self.assertEqual(changed.status_code, 200)
            cache.delete.assert_any_call(key)
            cache.delete.assert_any_call(f"examination_{self.exam_id}")
            self.assertEqual(cache.delete.call_count, 2)
            cache.scan_iter.assert_not_called()

    def test_unavailable_redis_reports_failure_without_hiding_saved_changes(self):
        from redis.exceptions import ConnectionError

        self.prepare()
        with patch("routes.student.redis_client") as cache:
            cache.get.side_effect = ConnectionError("Unavailable")
            with self.assertLogs(self.app.logger, level="ERROR"):
                response = self.call("examiner", "GET", f"/examinations/{self.exam_id}/rubrics")
            self.assertEqual(response.status_code, 503)
            self.assertIn("Redis is unavailable", response.json["message"])
        with patch("routes.admin.redis_client") as cache:
            cache.delete.side_effect = ConnectionError("Unavailable")
            with self.assertLogs(self.app.logger, level="ERROR"):
                response = self.call(
                    "admin", "POST", "/admin/courses",
                    {"code": "SAVED", "name": "Saved course", "description": ""},
                )
            self.assertEqual(response.status_code, 503)
            self.assertIn("may already be saved", response.json["message"])
        self.assertTrue(any(
            item["code"] == "SAVED"
            for item in self.call("admin", "GET", "/admin/courses").json["items"]
        ))

    def test_named_caches_refresh_after_related_changes(self):
        stored = {}
        self.cache.get.side_effect = stored.get
        self.cache.setex.side_effect = lambda key, ttl, value: stored.__setitem__(key, value)
        self.cache.delete.side_effect = lambda key: stored.pop(key, None)
        self.prepare()
        exam_path = "/examinations"
        slots_path = f"/examinations/{self.exam_id}/slots"
        first = self.call("admin", "GET", exam_path).json["items"][0]
        self.call("student", "GET", slots_path)
        self.call(
            "admin", "PUT", f"/admin/courses/{first['course_id']}",
            {"code": "CS101", "name": "Renamed course", "description": "", "status": "Active"},
        )
        self.assertEqual(
            self.call("admin", "GET", exam_path).json["items"][0]["course"], "Renamed course"
        )
        self.assertEqual(
            self.call("student", "GET", slots_path).json["items"][0]["course"], "Renamed course"
        )
        self.call(
            "admin", "PUT", f"/admin/users/{self.ids['examiner']}",
            {"name": "Renamed examiner", "department": "CS", "phone": "9000000000",
             "status": "Active"},
        )
        self.assertEqual(
            self.call("student", "GET", slots_path).json["items"][0]["examiner"],
            "Renamed examiner",
        )
        self.assertEqual(
            self.call("admin", "GET", exam_path).json["items"][0]["examiners"][0]["name"],
            "Renamed examiner",
        )
        self.open_booking()
        self.assertEqual(
            self.call("student", "GET", exam_path).json["items"][0]["status"], "Booking Open"
        )
        booked = self.call("student", "POST", "/student/bookings", {"slot_id": self.slot_id})
        self.assertEqual(booked.status_code, 201)
        slot = self.call("student", "GET", slots_path).json["items"][0]
        self.assertEqual((slot["status"], slot["available_seats"]), ("Full", 0))
        self.call("student", "POST", f"/student/bookings/{booked.json['id']}/cancel")
        slot = self.call("student", "GET", slots_path).json["items"][0]
        self.assertEqual((slot["status"], slot["available_seats"]), ("Available", 1))
        self.cache.scan_iter.assert_not_called()

    def test_dashboard_cache_hit_and_registration_invalidation(self):
        stored = {}
        self.cache.get.side_effect = stored.get
        self.cache.setex.side_effect = lambda key, ttl, value: stored.__setitem__(key, value)
        self.cache.delete.side_effect = lambda key: stored.pop(key, None)
        first = self.call("admin", "GET", "/admin/dashboard")
        self.assertEqual(first.status_code, 200)
        self.assertEqual(self.call("admin", "GET", "/admin/dashboard").json, first.json)
        self.cache.setex.assert_called_once()
        self.assertEqual(self.cache.setex.call_args.args[:2], ("admin_dashboard", 120))
        registered = self.app.test_client().post("/api/student/register", json={
            "name": "New", "email": "cache@example.test", "password": "123",
            "roll_number": "CACHE", "department": "CS", "phone": "9000000000",
        })
        self.assertEqual(registered.status_code, 201)
        self.assertEqual(
            self.call("admin", "GET", "/admin/dashboard").json["counts"]["students"],
            first.json["counts"]["students"] + 1,
        )
        before = self.cache.get.call_count
        self.assertEqual(self.call("student", "GET", "/admin/dashboard").status_code, 403)
        self.assertEqual(self.cache.get.call_count, before)

    def test_cached_rubrics_do_not_bypass_current_access_rules(self):
        self.prepare()
        path = f"/examinations/{self.exam_id}/rubrics"
        self.call("admin", "GET", path)
        self.cache.get.return_value = self.cache.setex.call_args.args[2]
        with self.app.app_context():
            exam = Examination.query.filter_by(id=self.exam_id).first()
            exam.status = "Draft"
            db.session.commit()
        before = self.cache.get.call_count
        self.assertEqual(self.call("student", "GET", path).status_code, 403)
        self.assertEqual(self.cache.get.call_count, before)

    def test_resource_course_methods_and_read_only_history(self):
        created = self.call(
            "admin",
            "POST",
            "/admin/courses",
            {"code": "MATH", "name": "Mathematics", "description": ""},
        )
        path = f"/admin/courses/{created.json['id']}"
        updated = self.call(
            "admin",
            "PUT",
            path,
            {"code": "MATH", "name": "Applied Mathematics", "description": "", "status": "Active"},
        )
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(
            self.call("admin", "GET", "/admin/courses").json["items"][0]["name"],
            "Applied Mathematics",
        )
        self.assertEqual(self.call("admin", "DELETE", path).status_code, 200)
        self.assertEqual(
            self.call("admin", "GET", "/admin/courses").json["items"][0]["status"], "Archived"
        )
        self.assertEqual(self.call("student", "POST", "/student/history", {}).status_code, 405)
        self.assertEqual(
            self.call("student", "GET", "/profile").json["user"]["student_id"],
            self.profile_ids["student"],
        )

    def test_examiner_slot_update_and_removal_methods(self):
        self.prepare()
        path = f"/examiner/slots/{self.slot_id}"
        updated = self.call("examiner", "PUT", path, {**self.slot_payload, "capacity": 2})
        self.assertEqual(updated.status_code, 200, updated.json)
        self.assertEqual(
            self.call("examiner", "GET", "/examiner/slots").json["items"][0]["capacity"], 2
        )
        self.assertEqual(self.call("examiner", "DELETE", path).status_code, 200)
        self.assertEqual(
            self.call("examiner", "GET", "/examiner/slots").json["items"][0]["status"], "Cancelled"
        )

    def test_celery_job_creates_its_own_application_context(self):
        result = send_monthly_report.apply().get()
        self.assertEqual(result, "Monthly Report Sent")
        self.smtp.sendmail.assert_called_once()

    def test_direct_validation_rejects_bad_json_and_preserves_slot(self):
        self.assertEqual(self.call("student", "POST", "/student/bookings", []).status_code, 400)
        self.prepare()
        path = f"/examiner/slots/{self.slot_id}"
        invalid = {**self.slot_payload, "start": "2026-01-01T10:00:00"}
        self.assertEqual(self.call("examiner", "PUT", path, invalid).status_code, 400)
        invalid = {**self.slot_payload, "capacity": True}
        self.assertEqual(self.call("examiner", "PUT", path, invalid).status_code, 400)
        slot = self.call("examiner", "GET", "/examiner/slots").json["items"][0]
        self.assertEqual(slot["start"], self.slot_payload["start"])
        self.assertEqual(slot["capacity"], self.slot_payload["capacity"])
        created = self.call("admin", "GET", "/admin/courses").json["items"][0]
        duplicate = {"code": created["code"], "name": "Duplicate", "description": ""}
        with self.assertLogs(self.app.logger, level="ERROR"):
            self.assertEqual(
                self.call("admin", "POST", "/admin/courses", duplicate).status_code, 409
            )
        self.assertEqual(len(self.call("admin", "GET", "/admin/courses").json["items"]), 1)

    def test_mail_failures_and_task_status_errors_are_explicit(self):
        import smtplib
        from redis.exceptions import RedisError

        with patch("routes.mail.PASSWORD", ""):
            with self.assertRaisesRegex(ValueError, "SMTP_PASSWORD"):
                send_monthly_report.apply().get()
        self.smtp.sendmail.side_effect = smtplib.SMTPException("Delivery failed")
        with self.assertRaises(smtplib.SMTPException):
            send_monthly_report.apply().get()
        with self.app.app_context():
            student = Student.query.filter_by(id=self.profile_ids["student"]).first()
            student.export_task_id = "unavailable-job"
            db.session.commit()
        with patch("routes.student.celery.AsyncResult", side_effect=RedisError("Unavailable")):
            with self.assertLogs(self.app.logger, level="ERROR"):
                result = self.call("student", "GET", "/student/exports")
        self.assertEqual(result.status_code, 503)


if __name__ == "__main__":
    unittest.main()
