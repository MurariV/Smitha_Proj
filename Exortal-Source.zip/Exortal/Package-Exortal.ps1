$ErrorActionPreference = 'Stop'
$destination = Join-Path $PSScriptRoot 'Exortal-Source.zip'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files = [System.Collections.Generic.List[object]]::new()
foreach ($folder in @('backend', 'frontend')) {
    $base = Join-Path $PSScriptRoot $folder
    $queue = [System.Collections.Generic.Queue[string]]::new()
    $queue.Enqueue($base)
    while ($queue.Count -gt 0) {
        $directory = $queue.Dequeue()
        foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
            if ($item.PSIsContainer) {
                if ($item.Name -notin @('instance', '__pycache__', 'node_modules', 'dist', 'test-results', 'playwright-report')) { $queue.Enqueue($item.FullName) }
            } elseif ($item.Extension -notin @('.pyc', '.log') -and $item.Name -ne '.env') {
                $files.Add($item)
            }
        }
    }
}
foreach ($name in @('Setup-Exortal.ps1', 'Start-Exortal.ps1', 'Stop-Exortal.ps1', 'Package-Exortal.ps1', 'RUNNING.txt', 'PROJECT-REPORT.html', '.gitignore')) {
    $files.Add((Get-Item -LiteralPath (Join-Path $PSScriptRoot $name)))
}
if (Test-Path (Join-Path $PSScriptRoot 'PROJECT-REPORT.pdf')) {
    $files.Add((Get-Item -LiteralPath (Join-Path $PSScriptRoot 'PROJECT-REPORT.pdf')))
}
$stream = [System.IO.File]::Open($destination, [System.IO.FileMode]::Create)
$archive = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($PSScriptRoot.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, "Exortal/$relative", [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $archive.Dispose(); $stream.Dispose() }
Write-Host "Source package created: $destination"
Write-Host 'Generated databases, credentials, signing secrets, logs and dependencies are excluded.'
